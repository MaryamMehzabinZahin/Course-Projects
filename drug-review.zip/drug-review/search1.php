



<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "drug_review";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>
	 <link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <link rel="stylesheet" type="text/css" href="Styles/s1.css" />
        <link rel="stylesheet" type="text/css" href="Styles/s2.css" />
	<title>PHP Lab Exercise 3</title>
	<style>
		table, th, td{
			border: 1px solid black;
			border-collapse: collapse;
			padding: 2px 5px;
		}
	</style>
</head>
<body>
	<h1>Review</h1>
	
	<table <div class="col-lg-5">
		<tr>
			<th>Drugname</th>
			<th>Condition</th>
			<th>Rating</th>
			<th>Review</th>
		</tr>
		<?php
			//Using POST
$src = $_GET['search'];
			
			//	if(is_numeric($_POST['search'])){
				//	$src = (int)$_POST['search'];
			//	}
			//	else{
			//		$src = $_POST["search"];
$stmt = $conn->prepare("select * from review 
				where drugName = '$src%' ");
			

				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();
			$stmt->bind_result($username,$password,$drugname, $conditions,$review,$rating,$date);







				while($stmt->fetch()){
					?>
					<tr>
					<?php
						echo 
						"<td>".
					     "<a href='search1_page2.php?var=$drugname'> " . $drugname."</a> " .
					    "</td>";
						
						?>
					</tr>
					<?php
				}
			
		?>
	</table>
</body>
</html>



