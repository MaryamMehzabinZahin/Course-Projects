
<?php
// Start the session
session_start();
?>



<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "drug_review";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>








<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "drug_review";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>PHP Lab Exercise 3</title>
	<style>
		table, th, td{
			border: 1px solid black;
			border-collapse: collapse;
			padding: 2px 5px;
		}
	</style>
</head>
<body>
	<h1>Insomnia</h1>
	
	<table <div class="col-lg-5">
		<tr>
			<th>Drugname</th>
			<th>Condition</th>
			<th>Rating</th>
			<th>Review</th>
		</tr>
		<?php
			//Using POST
//$src = $_POST['search'];
			
			//	if(is_numeric($_POST['search'])){
				//	$src = (int)$_POST['search'];
			//	}
			//	else{
			//		$src = $_POST["search"];
			//	}
				$stmt = $conn->prepare("select * from review where conditions = 'Insomnia' ");

				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();
			$stmt->bind_result($username,$password,$drugname, $conditions,$review,$rating,$date);




				while($stmt->fetch()){
				?>
					<tr>
					<?php
                  echo 
						"<td>".$drugname."</td>".
						"<td>".$conditions."</td>".
						"<td>".$rating."</td>".
						"<td>".$review."</td>" ;						?>
					</tr>
					<?php
				}
			
		?>
	</table>
</body>
</html>



