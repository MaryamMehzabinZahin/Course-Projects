<!DOCTYPE html>
<html>
<head>
	<title>welcome</title>
</head>
<body>
	<h1> welcome </h1>
	<!DOCTYPE HTML>  
<html>
<head>
</head>
<body>  

<?php

	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "drug_review";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<form method="post" action=" ">  
	 Drug Name: <input type="text" name="drug_name" >
  
  review: <input type="text" name="r" >
  
  
  
  <input type="submit" name="submit" value="Register">    
</form>




</body>

</html>

</body>
</html>
<?php
     

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
       
		$stmt = $conn->prepare("insert into reviewer values (?, ?, ?,?)");
		$stmt->bind_param("siss", $_POST["name"], $_POST["phone"], $_POST["drug_name"],$_POST['review']);
		$stmt->execute();
		$stmt->store_result();
}	
?>