<!DOCTYPE HTML>  
<html>
<head>
</head>
<body>  

<?php
// Start the session
session_start();
?>
<?php
   


?>
<?php
	 
 $name = $nameError=$subject=$mark=$subjectError=$markError=$phone=" ";
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
$link = mysqli_connect("localhost", "root", "", "drug_review");
 
if (!$link){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name=$_SESSION['username'];
    
 
   $drug_name=$_POST['drug_name'];
   $review=$_POST['review'];
   $conditions = $_POST['conditions'];
   $rating = $_POST['rating'];

// Attempt insert query execution
// $sql = "INSERT INTO reviewer (name, phone, drug_name,review) VALUES ('$name', '$phone', '$drug_name','$review')";
$sql="INSERT INTO review (username, drugName, conditions, review, rating) VALUES ('$name','$drug_name','$conditions','$review','$rating')";
if(mysqli_query($link, $sql)){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
mysqli_close($link);
}

?>
</body>
<form method="post" action=" ">  
  drug:<input type="text" name="drug_name" >

  Condition:<input type="text" name="conditions" >
  
  review: <input type="text" name="review" >

  Ratings: <input type="text" name="rating" >
  
   <input type="submit" name="submit" value="SUBMIT">    
</form>


</html>