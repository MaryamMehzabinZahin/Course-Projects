


<?php
include 'header1.php';
$src1= $_SESSION['username'];
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "drug_review";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>birth control</title>
	<style>
		 td{
			/*border: 1px solid black;
			border-collapse: collapse;*/

			padding: 2px 5px;
			color: navy;
		}
	</style>
</head>
<body>

      <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                	<h3>Drug information that you searched for</h3>
	
	
	<table >
		<!-- <tr>
			<th colspan="1">Username</th>
		</tr>
		<tr>	<th colspan="1">Email</th></tr>
		<tr>	<th colspan="1">Address</th>&nbsp</tr>
		<tr>	<th colspan="1">Phone</th></tr> -->
		
		<?php
			//Using POST
//$src = $_POST['search'];
			
			//	if(is_numeric($_POST['search'])){
				//	$src = (int)$_POST['search'];
			//	}
			//	else{
			//		$src = $_POST["search"];
			//	}
				$stmt = $conn->prepare("select distinct username,user_type, email,address,dob,gender,phone from user
				where username = '$src1' ");
			
/*$stmt = $conn->prepare("select  distinct drugname from review 
				where drugName like '$src%' ");
*/


				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();
			$stmt->bind_result($username, $user_type,$email,$address,$dob,$gender,$phone);




				while($stmt->fetch()){

			?>

					<tr>
					<?php
                  echo 
						"<tr>"."<th>"."username"."<td>".$username."</td>"."</tr>".
					                 "<tr>"."<th>"."email"."<td>".$email."</td>"."</tr>".
						"<tr>"."<th>"."address"."<td>".$address."</td>"."</tr>".
						"<tr>"."<th>"."phone"."<td>".$phone."</td>"."</tr>";					?>
					</tr>
					<?php
				}

			
		?>


		</table>
<br><br><br>
<table>
	<tr><td>
 <form method="get" action="editt.php">
    <input type="hidden" name="username" value=<?php echo  $username ;?>>
    <input type="hidden" name="email" value=<?php echo  $email ;?>>
    <input type="hidden" name="address" value=<?php echo  $address ;?>>
    <input type="hidden" name="phone" value=<?php echo  $phone;?>>
    <input type="hidden" name="password" value=<?php echo  $password;?>>
     <input type="hidden" name="dob" value=<?php echo $dob;?>>
    <input type="hidden" name="gender" value=<?php echo  $gender;?>>
    <input type="hidden" name="user_type" value=<?php echo  $user_type;?>>

    <input type="submit" value="edit" >
</form>
</td>
<td>
 <form method="get" action="delete.php">
    
    <input type="submit" value="Delete" >

</form>
</td></tr>
</table>
<div><?php
    
            if(isset($_SESSION['username'])){
                $user=$_SESSION['username'];


  echo
   "<script type=\"text/javascript\">
document.getElementById('myDIV').style.display = 'none';
document.getElementById('btn_review').style.display = 'block';



       </script>    
  ";
  echo  
"
    <h2 style='color:navy'>Hello $user !</h2>
         <div>
<a href='./logout.php'>Logout</a>

</div>

 
  ";

  }
            ?></div>
 
            
        </div>
    </section>
   
    <?php
    include 'footer.php';
    ?>
	</table>
</body>
</html>



