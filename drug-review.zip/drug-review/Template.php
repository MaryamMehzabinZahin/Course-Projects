


<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
    <head>

      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        
        <title>< DrugsReview.com></title>
        <link rel="stylesheet" type="text/css" href="Styles/s1.css" />
        <link rel="stylesheet" type="text/css" href="Styles/s2.css" />
    </head>
    <body >
        <div id="wrapper" >
            <div id="banner">
             

  <h1 style="font-size: 50px;color: blue;font-family: verdana"><left> Drugs.com </left></h1>




            </div>
            
           


            <div class="topnav">
              <a href="index.php" style="background-color: blue">Home</a>
               <a href="history.php">history</a>
              <a href="all.php">Drugs A to Z </a>
  <form method="post" action="s2.php">
    <input type="text" name="search" placeholder="Search medicine...">
   
</form>
</div>
 <div class="dropdown">
<h1><center>  <button onclick="myFunction()" class="dropbtn">search about medication</button></center></h1>
  <div id="myDropdown" class="dropdown-content">
 <center>   <input type="text" placeholder="Search.." id="myInput" onkeyup="filterFunction()"></center>
    <a href="birthcontrol.php">Birth Control</a>
    <a href="bipolar.php">Schizophrenia</a>
    <a href="insomnia.php">Insomnia</a>
   
  </div>
</div>
            
            <div id="myDIV">
                  <h1><center><bold>Want to give a review? <bold></center></h1>
                    <br>
                   <center> <a href="login.php">Log in</a></center> 
                  <center>  <p style="font-size: 20px">Don't have an account yet?</p></center> 
                  <center> <a href="n2.php">Register</a></center> 
               
            </div>
            
            <br>
            <br>
      <script>

if(isset($_SESSION['username'])){
  
 
function myFunction() {
  document.getElementById("myDIV").style.display = "none";
}
}
</script>     
<script>
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function filterFunction() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  div = document.getElementById("myDropdown");
  a = div.getElementsByTagName("a");
  for (i = 0; i < a.length; i++) {
    txtValue = a[i].textContent || a[i].innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      a[i].style.display = "";
    } else {
      a[i].style.display = "none";
    }
  }
}
</script>

<div class="container">
                 
  <ul class="pagination">
    <li><a href="index.php">1</a></li>
    <li><a href="history.php">2</a></li>
    <li><a href=" ">3</a></li>
    <li><a href="#">4</a></li>
    <li><a href="#">5</a></li>
  </ul>
</div>



            <div>
            <footer>
                <p>All rights reserved</p>
            </footer>
        </div>
    </body>
</html>
