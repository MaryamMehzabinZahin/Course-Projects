<?php 
session_start();	
/*if(!$_GET["usrname"]){
	header("Location: ./login.php");*/


$typ_username = $_GET['usrname'];
$typ_pass = $_GET['pass'];
$typ_pass1=$typ_pass;
//$typ_pass1=substr_replace($typ_pass1 ,"", -2);





$link = mysqli_connect("localhost", "root", "", "drug_review");

if(!$link){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

		

$QRY = "select password from user where username = '$typ_username'  ";

$result = $link->query($QRY);

$stmt = $link->prepare($QRY);
				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();

			$stmt->bind_result($password);

			$stmt->fetch();


if($typ_pass1==$password){

 $session['username'] = $_GET["usrname"];
	header("Location: ./review.php");
}
		


else{
	echo "$typ_pass";
	echo "           ";
	echo "$password";
}

// when successfull login then 
// if(qr_db_pass == $_GET["usrname"])
// 	successfull login

?>