<html>
<body>
<?php
$con = mysqli_connect('localhost','root','','hometutor') or die('Connection error!');

$q="select * from course ";
$query =mysqli_query($con,$q);
while($row=mysqli_fetch_assoc($query))
{
	   $id =$row['id']; 
	  
	  $name =$row['video'];
	  
	  echo "<a href ='watch.php?id=$id'>$name</a><br>";
	  
	  
}
?>
</body>
  </html>
