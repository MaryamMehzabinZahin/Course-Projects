 <?php session_start();



  ?>

 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!-- Title -->
    <title>Academy - Education Course Template</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">





</head>

<body>
    <!-- ##### Preloader ##### -->
    <div id="preloader">
        <i class="circle-preloader"></i>
    </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area">

        <!-- Top Header Area -->
        <div class="top-header">
            <div class="container h-100">
                <div class="row h-100">
                    <div class="col-12 h-100">
                        <div class="header-content h-100 d-flex align-items-center justify-content-between">
                            <div class="academy-logo">
                                <a href="index.html"><img src="img/core-img/logo.png" alt=""></a>
                            </div>
                            <div class="login-content">
                                <a href="logreg.php">Register / Login</a>
                            </div>
                          
                </div>
            </div>
        </div>

        <!-- Navbar Area -->
        <div class="academy-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="academyNav">

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- close btn -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            

                        <!-- Calling Info -->
                        
                    </nav>
                </div>
            </div>
        </div>
    </header>

<?php



$name = $email = $gender = $comment =$gender= $website =$pass=$add= $d=$a=$n=$phone=$ed=$city=$rd=$bd=$ad=$salary=$image="";
$nameErr = $emailErr = $genderErr = $websiteErr =$passErr=$addErr=$dErr=$nErr=$tr= $ex=$salaryErr= $crypt_pass="";
$ck=0;
$Reg = '[a-z]{2,6}$/i';
$f=0;
$c=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]{6,15}$/i",$name)) {
      $nameErr = "Username must be 6-15 chars long"; 
  }
  else
  {
    $ck++;
  }
}
if (empty($_POST["phone"])) {
    $nErr = "phone number is required";
  } else {
    $phone = test_input($_POST["phone"]);
    if (!preg_match('/^01[3-9]{1}\d{8}$/', $phone)) {
         $nErr = "number is not valid";
          }
        
             else
  {
    $ck++;
  }
        }




      

        

  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format"; 
    }
     else
  {
    $ck++;
  }
  }

  if (empty($_POST["pass"])) {
    $passErr = "pass is required";
  } else {
    $pass = test_input($_POST["pass"]);
    if (!preg_match("/\d/", $pass)) {
         $passErr = "Password should contain at least one number";
          }
        else  if (!preg_match("/[A-Z]/", $pass)) {
            $passErr = "Password should contain at least one uppercase Letter";
          }
         else if (!preg_match("/[a-z]/", $pass)) {
            $passErr= "Password should contain at least one lowercase Letter";
          }
        else
  {
    $ck++;
  }
          
  }

  
 


if (empty($_POST["d"])) {
    $dErr = "date is required";
  } else {
    $d = $_POST["d"];

 
//Create a DateTime object using the user's date of birth.
$dob = new DateTime($d);
 
//We need to compare the user's date of birth with today's date.
$now = new DateTime();
 
//Calculate the time difference between the two dates.
$difference = $now->diff($dob);
 
//Get the difference in years, as we are looking for the user's age.
$age = $difference->y;
 
//Print it out.
if ($age<15)
{
  $dErr = "sorry u can't enter because u r under 15 ";
}
 else
  {
    $ck++;
  }

}
}

 


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


  
     if($ck==5)
     {
     
       $name=$_POST['name'];
  $email=$_POST['email'];
 
  $ad=$_POST['ad'];
  $rd=$_POST['rd'];
  $bd=$_POST['bd'];
 
  $city=$_POST['city'];
  $phone=$_POST['phone'];
  $pass=$_POST['pass'];
  $salt ="$7@asdasdqwer_ojkjgjftygxwqwrtfiksdfghjkxcvbnm";
  $crypt_pass = crypt($pass, $salt);
  $dbcon=mysqli_connect("localhost", "root", "", "hometutor");
       
        $qry="INSERT INTO guardian(username, password,email,road,block,area,city,dob,phone)
 VALUES ('$name', '$crypt_pass', '$email','$rd','$bd','$ad','$city','$d','$phone')";

    
        if(mysqli_query($dbcon,$qry))
        {
           


  $_SESSION['username'] = $name;
  
  header("Location: ./index.php");

}

        }
        
 
     
    
    
?>


<div class="row">
    <div class="col-sm-4" >
      
    </div>
    <div class="col-sm-6" >
      <div class="container">
        
        <div class="container">
        
<p><span class="error">* required field</span></p>
<form method="post" action="" enctype="multipart/form-data"> 
  <table>
  <tr>
  <td>Username:       </td>
  <td><input type="text" name="name" value="<?php echo $name;?>" ></td>
  <td><span class="error">* <?php echo $nameErr;?></span></td></tr>
  <br>
 <tr>
  <td>      Password:          </td>
  <td><input type="text" name="pass" value="<?php echo $pass;?>"></td>
  <td><span class="error">* <?php echo $passErr;?></span></td></tr>
  <br>
  <tr>
 <td> Email:</td>
 <td> <input type="text" name="email"  value="<?php echo $email;?>"></td>
  <td><span class="error">* <?php echo $emailErr;?></span></td></tr>
  <br>
  
<tr><td>Road NO:</td>
  <td><input type="text" name="rd" value="<?php echo $rd;?>"></td>
   </tr>
 
 <tr><td>Block:</td>
  <td><input type="text" name="bd" value="<?php echo $bd;?>"></td>
  </tr>
 
 <tr><td>Area:</td>
  <td><input type="text" name="ad" value="<?php echo $ad;?>"></td>
  </tr>
 
 <tr><td>City:</td>
    <td><select name="city">
      <option value ="Dhaka" >Dhaka</option>
      <option value ="Chittagong">Chittagong</option>
      <option value ="Rajshahi">Rajshahi</option>
      <option value ="Comilla">Comilla</option>
      <option value ="Barisal">Barisal</option>
      <option value ="Rangpur">Rangpur</option>
      <option value ="Khulna">Khulna</option>
      <option value ="Mymensingh">Dhaka</option>

    </select></td>
	 </tr>
 
  <tr><td>Date of Birth:</td>
<td>  <input type="text" name="d" value="<?php echo $d;?>"></td>
 <td> <span class="error">* <?php echo $dErr;?></span></td></tr>
  
 
  <tr><td>Phone:</td>
<td>  <input type="text" name="phone" value="<?php echo $phone;?>" ></td>
  <td><span class="error">* <?php echo $nErr;?></span></td></tr>
 <tr><td><input type="submit" name="submit" value="Register" style="color: red">    </td></tr>
</table>
</form>

</div>
</div>
</div>
 <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>
</html>