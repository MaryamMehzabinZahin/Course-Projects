<?php 

$db = mysqli_connect('localhost','root','','hometutor') or die('Connection error!');

?>