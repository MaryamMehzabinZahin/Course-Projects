

<?php

	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "hometutor";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>
	 <link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <link rel="stylesheet" type="text/css" href="Styles/s1.css" />
        <link rel="stylesheet" type="text/css" href="Styles/s2.css" />
	<title>PHP Lab Exercise 3</title>
	<style>
		table, th, td{
			border: 1px solid black;
			border-collapse: collapse;
			padding: 2px 5px;
		}
	</style>
</head>
<body>

    <!-- Header Area Starts -->
   
 
     
      <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                	<h1>teacher Names</h1>

		<?php
			
				

	$stmt = $conn->prepare("select id,image from images");
				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();
			$stmt->bind_result( $id,$image);



while($stmt->fetch()){
				?>
					<tr>
					<?php
					
					echo $id;
					echo '<img style="width:50px;height:60px;" src="data:image/jpeg;base64, '.base64_encode($image).'">';

					//echo "<img src='data:image/jpeg;base64,'.base64_encode($image)>";

					    
						?>
					</tr>
					<?php
				}
			
		?>

				

</body>

</html>



