<?php
   $r_id=$_GET['var'];
   echo $r_id;
	 $dbcon=mysqli_connect("localhost", "root", "", "hometutor");
       
        $qry="DELETE FROM tutor_req1 WHERE r_id like '$r_id'";

    
        if(mysqli_query($dbcon,$qry))
        { 

            header('Location: tr2.php');
            
        }
        else
        { echo " error ";
        }
     
?>
	