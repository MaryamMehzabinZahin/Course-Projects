 
 <?php

if(isset($_SESSION['username'])){
	header("Location: ./index.php");
}

?>

<!DOCTYPE html>
<html>
<head>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<title>Login </title>
</head>
<body>
	 <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
				<h3>Login</h3>
				<div class="container">
				  
				  <form method="GET" action="tsubmit.php">
				    <div class="form-group">
				      <label for="usr">Name:</label>
				      <input type="text" class="form-control" name="usrname" id="usr">
				    </div>
				    <div class="form-group">
				      <label for="pwd">Password:</label>
				      <input type="password" class="form-control" name="pass" id="pwd">
				    </div>
				    <div>
				    	
				    </div>
				    <div>
				    	<input type="checkbox" name="rememberme" value="rememberme">Remember Me<br><br>
				    </div>

				    <button type="submit" class="btn btn-info" value="submit">Login</button>
				  </form>
				</div>
			</div>
		 </div>
 
            
        </div>
    </section>
    
	
</body>


</html>