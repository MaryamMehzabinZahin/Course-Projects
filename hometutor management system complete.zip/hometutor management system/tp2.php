<?php
   $r_id=$_GET['var'];
   echo $r_id;
	 $dbcon=mysqli_connect("localhost", "root", "", "hometutor");
       
        $qry="INSERT tutor
SELECT * FROM tutor_req1 where r_id like '$r_id'";

    
        if(mysqli_query($dbcon,$qry))
        {
            echo " <br/>Image uploaded.";
            
        }
        else
        { echo " error ";
        }
      header("Location:delete.php?var=$r_id");
?>
	