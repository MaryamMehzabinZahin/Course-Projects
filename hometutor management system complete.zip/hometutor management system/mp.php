<html>
<body>
    <style>
        #map {
            height: 300px;
            width: 800px;
        }
    </style>
    <h3><center>See us in Google map</center>  </h3>
    <div id="map"></div>

    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script>
        
        function area() {
            var location = "south badda,Dhaka, Bangladesh";
            return location;
        }
    </script>

    <script src="googlemap.js"></script>

    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAcNrI8A1S4IInSiDqN730I5moq-Hv-k88&callback=initMap">
    </script>
</body>
</html>