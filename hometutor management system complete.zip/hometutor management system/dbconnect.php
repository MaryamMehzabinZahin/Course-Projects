


<?php


	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "hometutor";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

