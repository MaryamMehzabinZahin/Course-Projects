<?php include 'header.php'; ?>

    <!-- ##### Breadcumb Area Start ##### -->
    <div class="breadcumb-area bg-img" style="background-image: url(img/bg-img/breadcumb.jpg);">
        <div class="bradcumbContent">
            <h2>About Us</h2>
        </div>
    </div>
    <!-- ##### Breadcumb Area End ##### -->

    <!-- ##### About Us Area Start ##### -->
    <section class="about-us-area mt-50 section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center mx-auto wow fadeInUp" data-wow-delay="300ms">
                        <span>The Best</span>
                          <h1>Hometutors.com </h1>
                          <p>
                         <a href='tr2.php' class='btn btn-link' > upload new tutorial
                          
                         <a href='tr2.php' class='btn btn-link' > See All confirmed tutors
                    </p>
                    
                    </div>
                </div>
            </div>
            
        </div>
    </section>
    <?php include 'footer.php'; ?>
    <!-- ##### About Us Area End ##### -->

    
    <!-- ##### Features Area Start ##### -->

    <!-- ##### Footer Area Start ##### -->
    
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
   