<!DOCTYPE html>
<html>
<head>
	<title></title>
<!-- Script -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>


<style>
	.select2-container .select2-selection--single{
    height:34px !important;
}
.select2-container--default .select2-selection--single{
         border: 1px solid #ccc !important; 
     border-radius: 0px !important; 
}

</style>
</head>
<body>
	<div class="container">
	<div class="row">
	    <form class="col-md-4" action="sf2.php">
	        <label>Search by Gender</label> 
	        <select class="form-control select2" name='gender' >
	           
	           <option>Male</option> 
	           <option>Female</option> 
	          
	        </select>
	        <br>
	          <label>Search by Medium</label> 
	        <select class="form-control select2" name='medium' >
	           
	           <option>Bangla</option> 
	           <option>English</option> 
	           <option>Both</option> 
	          
	        </select>
	        <br>
	          <label>Search by City</label> 
	        <select class="form-control select2" name='city' >
	           
	            <option  >Dhaka</option>
      <option >Chittagong</option>
      <option >Rajshahi</option>
      <option >Comilla</option>
      <option >Barisal</option>
      <option >Rangpur</option>
      <option >Khulna</option>
      <option >Dhaka</option>

	        </select>
	           <br>
	          <label>Search by Area-Covered</label> 
	        <select class="form-control select2" name='area_covered' >
	       <option >aftabnagar</option>    
	            <option  >Banani</option>
      <option >Bashabo</option>
      <option >Uttara</option>
      <option >Rampura</option>
      <option >Gulshan</option>
      
      <option >Mirpur</option>
      

	        </select>

 <br>
	          <label>Search by Salary </label> 

 <input type="text" name="salary" required><br>
 <label>Search by Subjects</label> 
 <input type="text" name="sub" required><br>
   <br>
	          <label>Search by Class</label> 

 <input type="text" name="class" required><br>
 
 <input type="submit" name="submit" value="Search Now">   
	    </form>
 	</div>
</div>
<script>
    $('.select2').select2();
</script>
</body>

</html>