<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}

  .graybox {
    background-color: #f2f1e3;
    border: 1px solid #d3ceb4;
    padding: 10px;
  }
  .dbox {
    background-color:   #f7f9f9;
    padding: 10px;
  }

    .tab-border {
    text-align: center;
    border: 1px solid black;
  }
</style>
</head>
<body>  


<div class="row">
    <div class="col-sm-4" >
      
    </div>
    <div class="col-sm-6" >
      <div class="container">
        
        <div class="container">
        
<p><span class="error">* required field</span></p>
<form method="post" action="/project/reg.php">  
  Username: <input type="text" name="name" >
  <span class="error">* </span>
  <br><br>
  Password: <input type="text" name="pass">
  <span class="error">* </span>
  <br><br>
  Email: <input type="text" name="email">
    <span class="error">* </span>
  <br><br>
  Address: <input type="text" name="add" >
  <span class="error">* </span>
  <br><br>
  Date of Birth: <input type="text" name="d">
  <span class="error">* </span>
  <br><br>
 
  Gender:
  <input type="radio" name="gender"  value="female">Female
  <input type="radio" name="gender"  value="male">Male
  <input type="radio" name="gender"  value="other">Other  
  <span class="error">* </span>
  <br><br>
  Phone: <input type="text" name="phone" >
  <span class="error">* </span>
  <br><br>
  
 user_type:
  <input type="radio" name=" user_type"  value="User">User
  <input type="radio" name=" user_type"  value="Admin">Admin
  <br><br>
 <input type="submit" name="submit" value="Register">     

</form>

</div>
</div>
</div>


</body>
</html>