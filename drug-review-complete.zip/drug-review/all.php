<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "drug_review";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>all drugs</title>
	<style>
		table, th, td{
			border: 1px solid black;
			border-collapse: collapse;
			padding: 2px 5px;
		}
	</style>
</head>
<body>
	<h1>All medicines</h1>
	<form action="" method="POST">
		<table <div class="col-lg-5">
		<tr>
			<th>Drugname</th>
			<th>Condition</th>
			<th>Rating</th>
			<th>Review</th>
		</tr>
			<?php
				$stmt = $conn->prepare("select * from review");
				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();

			$stmt->bind_result($username,$password,$drugname, $conditions,$review,$rating,$date);


			while($stmt->fetch()){
				?>
					<tr>
					<?php
                  echo 
						"<td>".$drugname."</td>".
						"<td>".$conditions."</td>".
						"<td>".$rating."</td>".
						"<td>".$review."</td>" ;						?>
					</tr>
					<?php
				}
			
		?>
		</table>
	</form>	
</body>
</html>



