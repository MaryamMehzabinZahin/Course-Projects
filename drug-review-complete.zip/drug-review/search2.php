



<?php
include 'header1.php';
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "drug_review";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>
	 <link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <link rel="stylesheet" type="text/css" href="Styles/s1.css" />
        <link rel="stylesheet" type="text/css" href="Styles/s2.css" />
	<title>PHP Lab Exercise 3</title>
	<style>
		table, th, td{
			border: 1px solid black;
			border-collapse: collapse;
			padding: 2px 5px;
		}
	</style>
</head>
<body>

    <!-- Header Area Starts -->
   
 
     
      <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                	<h1>Drug Names</h1>

		<?php
			//Using POST
$src = $_GET['search'];
			
			//	if(is_numeric($_POST['search'])){
				//	$src = (int)$_POST['search'];
			//	}
			//	else{
			//		$src = $_POST["search"];
			//	}
				$stmt = $conn->prepare("select  distinct conditions from review 
				where conditions like '$src%' ");
				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();
			$stmt->bind_result( $conditions);




				while($stmt->fetch()){
				?>
					<tr>
					<?php
						echo 
						
					     "<a href='search2_page2.php?var=$conditions'> " . $conditions."</a> " ."<br>";
					    
						
						?>
					</tr>
					<?php
				}
			
		?>
	</table>
	<br><br><br><br><br><br>

<?php
    
            if(isset($_SESSION['username'])){
                $user=$_SESSION['username'];


  echo
   "<script type=\"text/javascript\">
document.getElementById('myDIV').style.display = 'none';
document.getElementById('btn_review').style.display = 'block';



       </script>    
  ";
  echo  
"
    <h2 style='color:navy'>Hello $user !</h2>
         <div>
<a href='./logout.php'>Logout</a>
</div>

 
  ";

  }
            ?>


 </div>
            
        </div>
    </section>
    <?php
    include 'footer.php';
    ?>

</body>

</html>



