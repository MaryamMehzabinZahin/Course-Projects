<?php
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "drug_review";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>PHP Lab Exercise 3</title>
	<style>
		table, th, td{
			border: 1px solid black;
			border-collapse: collapse;
			padding: 2px 5px;
		}
	</style>
</head>
<body>
	<h1>Html form and validation</h1>
	<form action="" method="POST">
		<table>
			<tr>
				<td>Search</td>
				<td>
					<input type="text" name="search">
				</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit"></td>
			</tr>
		</table>
	</form>
	<table>
		<tr>
			<th>Name</th>
			<th>Subject</th>
			<th>Mark</th>
		</tr>
		<?php
			if(isset($_POST['search'])){
				$src = "";
				if(is_numeric($_POST['search'])){
					$src = (int)$_POST['search'];
				}
				else{
					$src = $_POST["search"];
				}
				$stmt = $conn->prepare("select * from review 
				where drugName like '$src%' ");
				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();
			$stmt->bind_result($uniqueID, $drugname, $condition,$review,$rating,$date,$usefulCount);



				while($stmt->fetch()){
				?>
					<tr>
					<?php
echo "<td>".$drugname."</td>"."<td>".$condition."</td>"."<td>".$rating."</td>";
						?>
					</tr>
					<?php
				}
			}
		?>
	</table>
</body>
</html>



