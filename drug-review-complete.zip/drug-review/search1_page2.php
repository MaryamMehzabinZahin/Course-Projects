


<?php
include 'header1.php';
$src1= $_GET['var'];
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "drug_review";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>birth control</title>
	<style>
		 td{
			/*border: 1px solid black;
			border-collapse: collapse;*/

			padding: 2px 5px;
			color: navy;
		}
	</style>
</head>
<body>

      <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                	<h3>Drug information that you searched for</h3>
	
	
	<table >
		<tr>
			<th>Drugname</th>
			<th>Condition</th>&nbsp &nbsp &nbsp
			<th>Rating</th>
			<th>Review</th>
		</tr>
		<?php
			//Using POST
//$src = $_POST['search'];
			
			//	if(is_numeric($_POST['search'])){
				//	$src = (int)$_POST['search'];
			//	}
			//	else{
			//		$src = $_POST["search"];
			//	}
				$stmt = $conn->prepare("select distinct drugname, conditions,review,rating from review 
				where drugName = '$src1' ");
			
/*$stmt = $conn->prepare("select  distinct drugname from review 
				where drugName like '$src%' ");
*/


				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();
			$stmt->bind_result($drugname, $conditions,$review,$rating);




				while($stmt->fetch()){

			?>

					<tr>
					<?php
                  echo 
						"<td>".$drugname."</td>".
						"<td>".$conditions."</td>".
						"<td>".$rating."</td>".
						"<td>".$review."</td>" ;						?>
					</tr>
					<?php
				}

			
		?>


		</table>
<br><br><br><br><br><br>

<div><?php
    
            if(isset($_SESSION['username'])){
                $user=$_SESSION['username'];


  echo
   "<script type=\"text/javascript\">
document.getElementById('myDIV').style.display = 'none';
document.getElementById('btn_review').style.display = 'block';



       </script>    
  ";
  echo  
"
    <h2 style='color:navy'>Hello $user !</h2>
         <div>
<a href='./logout.php'>Logout</a>
</div>
 
  ";

  }
            ?></div>
 
            
        </div>
    </section>
    <?php
    include 'footer.php';
    ?>
	</table>
</body>
</html>



