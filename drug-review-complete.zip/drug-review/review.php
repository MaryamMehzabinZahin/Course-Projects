



<!DOCTYPE HTML>  



<html>
<head>
	<link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <link rel="stylesheet" type="text/css" href="Styles/s1.css" />
        <link rel="stylesheet" type="text/css" href="Styles/s2.css" />
        <style>
		 table,td{
			
			padding: 15px;
			color: navy;
		}
	</style>
</head>
<body>  

 
<?php
include 'header1.php';

	 
 $name = $nameError=$subject=$mark=$subjectError=$markError=$phone=" ";
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
$link = mysqli_connect("localhost", "root", "", "drug_review");
 
if (!$link){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name=$_SESSION['username'];
    
 
   $drug_name=$_POST['drug_name'];
   $review=$_POST['review'];
   $conditions = $_POST['conditions'];
   $rating = $_POST['rating'];

// Attempt insert query execution
// $sql = "INSERT INTO reviewer (name, phone, drug_name,review) VALUES ('$name', '$phone', '$drug_name','$review')";
$sql="INSERT INTO review (username, drugName, conditions, review, rating) VALUES ('$name','$drug_name','$conditions','$review','$rating')";
if(mysqli_query($link, $sql)){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
mysqli_close($link);
}

?>
 <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                	<h1>Give the Review Here </h1>
	
	
	<table >
		

<form method="post" action=" ">  

	<table >
  <tr><td>drugname:<input type="text" name="drug_name" ></td></tr><br> <br> 

  <tr><td>Condition :<input type="text" name="conditions" ></td></tr><br><br>

  
  <tr><td>review :&nbsp &nbsp &nbsp<input type="text" name="review" ></td></tr><br><br>
 
 


   <tr><td>Ratings: &nbsp&nbsp <input type="text" name="rating" ></td></tr> <br><br>


  </table>
  <div>
  
    <h3><input type="submit" name="submit" value="SUBMIT">    <h3> 

</div>

</form>
<div>
<a href="./logout.php">Logout</a>
</div>

 
            
        </div>
    </section>
    <?php
    include 'footer.php';
    ?>
	</table>
</body>
</html>