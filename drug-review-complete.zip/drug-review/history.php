
<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" href="Styles/Stylesheet.css" />
<head>
	<title>History</title>
</head>
<body>
	
 <?php
$title = "Home";
$content = '<img src="images.jpg" class="imgLeft" />

<h3>Title 3</h3>
<p>
    Early medical traditions include those of Babylon, China, Egypt and India. The Indians introduced the concepts of medical diagnosis, prognosis, and advanced medical ethics. The Hippocratic Oath was written in ancient Greece in the 5th century BCE, and is a direct inspiration for oaths of office that physicians swear upon entry into the profession today. In the Middle Ages, surgical practices inherited from the ancient masters were improved and then systematized in Rogerius The Practice of Surgery. Universities began systematic training of physicians around 1220 CE in Italy.
</p>';


?>

<div id="content_area">
                <?php echo $content; ?>
            </div>
</body>



</html>



