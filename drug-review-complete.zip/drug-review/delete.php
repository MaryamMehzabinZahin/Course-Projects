

<?php
include 'header1.php';

            if(isset($_SESSION['username'])){
                $user=$_SESSION['username'];

echo "$user";

  $link = mysqli_connect("localhost", "root", "", "drug_review");
 
// Check connection
if(!$link){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt insert q('$username', '$pass', '$email','$address','$dob','$gender','$phone'uery execution


$sql="DELETE FROM user
WHERE username = '$user' ";
if(mysqli_query($link, $sql)){
   
		?>
		 <script>
		alert('Record deleted...');
        window.location='header.php'
        </script> 
		<?php
        session_destroy(); 
        setcookie('name',$user,time() + 86400);
        header("Location: ./header.php");
	}
	else
	{
		?>
		<script>
		alert('error deleting record...');
        window.location='header.php'
        </script>
		<?php
	}


 
// Close connection
mysqli_close($link);
}

include 'footer.php';

?>


