<?php

$var_value = $_GET['username'];
$var_value1 = $_GET['email'];
$var_value2 = $_GET['address'];
$var_value3= $_GET['phone'];
$var_value4= $_GET['password'];
$var_value5= $_GET['dob'];
$var_value6= $_GET['gender'];
$var_value7= $_GET['user_type'];



// data update code starts here.
if(isset($_POST['btn_update']))
{




  $username=$_POST['username'];
  $email=$_POST['email'];
  $address=$_POST['address'];
  $phone=$_POST['phone'];
  $pass=$_POST['password'];
  $link = mysqli_connect("localhost", "root", "", "drug_review");
 
// Check connection
if(!$link){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt insert q('$username', '$pass', '$email','$address','$dob','$gender','$phone'uery execution

$sql2="delete from user where username='$username'";


$sql="INSERT INTO user (username,user_type, password,email,address,dob,gender,phone ) VALUES ('$username','$var_value7', '$pass', '$email','$address','$var_value5','$var_value6','$phone')  ";
if(mysqli_query($link, $sql)){
    echo "Records inserted successfully.";
	
		?>
		<script>
		alert('Record updated...');
        window.location='header.php'
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('error updating record...');
        window.location='header.php'
        </script>
		<?php
	}


 
// Close connection
mysqli_close($link);
}





?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PHP Database Operation Using OOP</title>
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
<center>



<div id="body">
	<div id="content">
    <form method="post">
    <table align="center">
 
   
    <tr>
    <td>
        <?php
    echo "$var_value";
    ?>
      <tr>
    <td><input type="text" name="username" placeholder="user Name" value="<?php echo "$var_value"; ?>"  /></td>
    </tr>
    <tr>
    <td><input type="text" name="email" placeholder="email" value="<?php echo "$var_value1"; ?>"  /></td>
    </tr>
    <tr>
    <td><input type="text" name="address" placeholder="address" value="<?php echo "$var_value2"; ?>"  /></td>
    </tr>
    <tr>
    <td><input type="text" name="phone" placeholder="phone" value="<?php echo "$var_value3"; ?>"  /></td>
    </tr>
    <tr>
    <td><input type="text" name="password" placeholder="password" value="<?php echo "$var_value4"; ?>"  /></td>
    </tr>
    <button type="submit" name="btn_update"><strong>UPDATE</strong></button></td>
    </tr>
    </table>
    </form>
    </div>
</div>



</center>
</body>
</html>