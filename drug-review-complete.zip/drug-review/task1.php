<!DOCTYPE HTML>  
<html>
<head>
</head>
<body>  

<?php
	
 
 $name = $nameError=$subject=$mark=$subjectError=$markError="";
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
$link = mysqli_connect("localhost", "root", "", "drug_review");
 
// Check connection
if(!$link){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 $name=$_POST['name'];
  $phone=$_POST['phone'];
   $drug_name=$_POST['drug_name'];
    $review=$_POST['review'];

// Attempt insert query execution
$sql = "INSERT INTO reviewer (name, phone, drug_name,review) VALUES ('$name', '$phone', '$drug_name','$review')";
if(mysqli_query($link, $sql)){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
</body>
<form method="post" action=" ">  
  drug:<input type="text" name="drug_name" >
  
  review: <input type="text" name="review" >
  
   <input type="submit" name="submit" value="SUBMIT">    
</form>


</html>