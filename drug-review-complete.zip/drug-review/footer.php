<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 <div>
            <footer style="background-color: powderblue">
                <p >All rights reserved</p>
            </footer>
        </div>
</body>
</html>