


 
 
<?php
$cname="";
?>
<?php
$cname=$_POST['cname'];

$con=mysqli_connect("localhost","root","","hometutor");
if(isset($_POST['submit']))
{     
     
	 
	 $name=$_FILES['file']['name'];
	 $temp=$_FILES['file']['tmp_name'];
	 move_uploaded_file($temp,"upload/".$name);
	
	 $q="INSERT INTO `course`(`id`,`course_name`,`video`)VALUES ('','$cname','$name')";
	 
	 if(mysqli_query($con,$q))
	 {
		 echo "submitted to Database...";
	 }
	 echo "<br>".$name. "has been uploaded.";
	 //echo "<br>".$cname;
	 
}


 
?>
<html>
<head>

<meta charset="UTF-8">
<title>Video Upload </title>
</head>
<body>
  <form  method="POST" enctype="multipart/form-data">
  <input type="file" name="file" /><br>
   course_name:</td><td><input type="text" name="cname" value=""><br>
  <input type="submit" name="submit" value="Upload">
  
	
	 
	 
 </form>
</body>
</html>

