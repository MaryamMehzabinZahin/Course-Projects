<!DOCTYPE html>
<html>
<head>
	<title>Users list</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<?php 

session_start();

if(isset($_SESSION['id'])){
	$id = $_SESSION['id'];

}else {
	header('Location : login.php');
}


	require 'db.php';
	
	//echo $id;
	$sql = "SELECT * FROM admin WHERE `id` = '$id' ";
	$act = $db->query($sql);
	
	if($act->num_rows > 0){
		//print_r($act);
		while($row = $act->fetch_assoc()){
		<table>
		<tr>profile</tr>
		<tr>
		<td>ID</td>
		<td><?php echo $row['id']; ?></td>
		</tr>
		<tr><td>Name</td>
		<td><?php echo $row['name']; ?></td></tr>
		<tr><td>Email</td>
		<td><?php echo $row['email']; ?></td></tr>
		
		
		
		<tr>
			<td><a href="index.php" style="text-decoration: underline; float: right">Go Home</a></td>
		</tr>
	</table>

		}
	}
	

?>


	

</body>
</html>