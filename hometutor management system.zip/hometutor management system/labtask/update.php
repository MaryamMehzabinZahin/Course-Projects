<?php 

$current = $_POST['oldpassword'];
$pass = $_POST['password'];
$confirm = $_POST['newpassword'];
$id = $_POST['id'];


require 'db.php';

$sql2 = "SELECT * FROM admin WHERE `id` = '$id' AND `password` = '$current' " ;
$act = $db->query($sql2);

$row = mysqli_num_rows($act);

if($row == 0){
	$_SESSION['error'] = 'Password not match';
	header('Location: change.php');
	
}

if($pass != $confirm){
	$_SESSION['error'] = 'Password not match';
	header('Location: change.php');
} else{

	$sql = "Update `admin` SET `password` = '$pass' WHERE `id` = '$id'";
	$act = $db->query($sql);

	header('Location: index.php');
}
?>