<?php 

//require 'db.php';
$db = mysqli_connect('localhost','root','','hometutor') or die('Connection error!');
session_start();

$id = $_POST['id'];
$name = $_POST['name'];
$pass = $_POST['password'];
$confirm = $_POST['confirmpassword'];
$email = $_POST['email'];




echo  $id. ' '. $name . ' '.$pass. ' '. $confirm. ' '.$email;
if($pass != $confirm){
	$_SESSION['error'] = 'Password not match';
	header('Location: registration.php');
}


$sql = "SELECT * FROM admin";
$sql2 = "INSERT INTO `admin`(`id`, `name`,`Password`,`confirm_password`, `email`) VALUES ('$id','$name','$pass','$confirm','$email')";

$act = $db->query($sq12);
$row = mysqli_num_rows($act);

if($row >= 1){
	$_SESSION['error'] = 'ID already registered';
} else {
	$act2 = $db->query($sql2);

	header('Location: login.php');
}


?>