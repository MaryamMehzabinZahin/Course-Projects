<?php 

$current = $_POST['oldemail'];
$email = $_POST['email'];
$confirm = $_POST['newemail'];
$id = $_POST['id'];


require 'db.php';

$sql2 = "SELECT * FROM admin WHERE `id` = '$id' AND `email` = '$current' " ;
$act = $db->query($sql2);

$row = mysqli_num_rows($act);

if($row == 0){
	$_SESSION['error'] = 'Email not match';
	header('Location: change2.php');
	
}

if($email != $confirm){
	$_SESSION['error'] = 'Email not match';
	header('Location: change2.php');
} else{

	$sql = "Update `admin` SET `email` = '$email' WHERE `id` = '$id'";
	$act = $db->query($sql);

	header('Location: index.php');
}
?>