<?php 

//require 'db.php';
$db = mysqli_connect('localhost','root','','hometutor') or die('Connection error!');
session_start();

$id = $_POST['id'];
$pass = $_POST['password'];
$rememberme = $_POST['rememberme'];



$sql = "SELECT * FROM admin WHERE `id` = '$id' AND `password` = '$pass' ";

$act = $db->query($sql);
$row = mysqli_num_rows($act);

foreach ($act as $key) {
	$name = $key['name'];
	
}

if($row >= 1){
	if($rememberme == 'check'){
		setcookie('login', 'yes', time() + (86400 * 30), "/");
		setcookie('id', $id, time() + (86400 * 30), "/");
		setcookie('name', $name, time() + (86400 * 30), "/");
		
	}

	$_SESSION['id'] = $id;
	
	$_SESSION['name'] = $name;

	header('Location: index.php');

} else {
	$_SESSION['error'] = 'ID / Password is not match';

	header('Location: login.php');
}


?>