<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<?php 

	session_start();
	if(!isset($_SESSION['id'])){
		header('Location: index.php');
	}

	?>

	<fieldset>
		<legend>Change Email</legend>
		<form action="update2.php" method="post">
			<input type="text" name="id" value="<?php echo $_SESSION['id']; ?>"> <br>

			Current Email <br>
			<input type="text" name="oldemail"> <br>
			New Email <br>
			<input type="text" name="email"> <br> 
			Retype New Email <br>
			<input type="text" name="newemail"> <br> <br>
			
	<?php 

		if(isset($_SESSION['error'])){
	
		echo '<li>'. $_SESSION['error'] . '</li>';

		unset($_SESSION['error']);
		}

 	?>

			<hr>
			<input type="submit" name="login" value="Change">
			<a href="index.php">Home</a>
		</form>
	</fieldset>



</body>
</html>