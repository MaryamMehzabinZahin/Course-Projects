<!DOCTYPE html>
<html>
<head>
	<title></title>
<!-- Script -->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>


<style>
	.select2-container .select2-selection--single{
    height:34px !important;
}
.select2-container--default .select2-selection--single{
         border: 1px solid #ccc !important; 
     border-radius: 0px !important; 
}

</style>
</head>
<body>
	<div class="container">
	<div class="row">
	    <form class="col-md-4" action="zahin.php">
	        <label>Search by Gender</label> 
	        <select class="form-control select2" name='gender' >
	           
	           <option>Male</option> 
	           <option>Female</option> 
	          
	        </select>
	         <select class="form-control select2" name='area' >
	           
	           <option>Male</option> 
	           <option>Female</option> 
	          
	        </select>

 <input type="submit" name="submit" value="Register">   
	    </form>
 	</div>
</div>
<script>
    $('.select2').select2();
</script>
</body>

</html>