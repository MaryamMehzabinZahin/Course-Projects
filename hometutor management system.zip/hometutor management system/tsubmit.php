<?php 
session_start();	
if(!$_GET["usrname"]){
	header("Location: ./tlogin.php");
}

$typ_username = $_GET['usrname'];
$typ_pass = $_GET['pass'];
$rememberme = $_GET['rememberme'];


$link = mysqli_connect("localhost", "root", "", "hometutor");

if(!$link){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

		if($rememberme == 'check')
		{
			
			setcookie('name',$typ_username,time() + 86400);
		
		}
	

$QRY = "select password from tutor where username = '$typ_username'  ";

$result = $link->query($QRY);

$stmt = $link->prepare($QRY);
				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();

			$stmt->bind_result($password);

			$stmt->fetch();

if($typ_pass==$password){
	
 
	$_SESSION['username'] = $typ_username;
	header("Location: ./index.php");
}
		

else{
	header("Location: ./tlogin.php");	;
}

// when successfull login then 
// if(qr_db_pass == $_GET["usrname"])
// 	successfull login
// $session['username'] = $_GET["usrname"];
?>