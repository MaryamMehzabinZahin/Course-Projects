

<style type="text/css">
#box {
  margin: auto;
 
  border: 3px solid #73AD21
}
</style>


<?php include 'header.php'; ?>

    <!-- ##### Breadcumb Area Start ##### -->
    <div class="breadcumb-area bg-img" style="background-image: url(img/bg-img/breadcumb.jpg);">
        <div class="bradcumbContent">
            <h2>See Full Information</h2>
        </div>
    </div>
    <!-- ##### Breadcumb Area End ##### -->

    <!-- ##### About Us Area Start ##### -->
    <section class="about-us-area mt-50 section-padding-100">
        <div class="container" >
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center mx-auto wow fadeInUp" data-wow-delay="300ms">
                        <span>The Best</span>
                          <h1>Hometutors.com </h1>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-6 wow fadeInUp" data-wow-delay="400ms" >
                  
                    <p>
<?php
   $r_id=$_GET['var'];
  $server = "localhost";
  $username = "root";
  $password = "";
  $database = "hometutor";

  $conn = new mysqli($server, $username, $password, $database);

  if($conn->connect_error){
    die("Connecntion Failed: " . $conn->connect_error);
  }
  else{
    //echo "Connencted Succesfully";
  }
?>


<!DOCTYPE html>
<html>
<head>
   <link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <link rel="stylesheet" type="text/css" href="Styles/s1.css" />
        <link rel="stylesheet" type="text/css" href="Styles/s2.css" />
  <title> </title>
  <style>
    table, th, td{
      border: 1px solid black;
      border-collapse: collapse;
      padding: 2px 5px;
    }
  </style>
</head>
<body>

    <!-- Header Area Starts -->
   
 
     <?php
      $stmt = $conn->prepare("select distinct username, r_id,email,phone,road,block,area,city,gender,ex,salary,image,subjects,area_covered,medium,class from tutor_req1
         where r_id='$r_id' ");
      

        //$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
        $stmt->execute();
         $stmt->bind_result($username, $r_id,$email,$phone,$road,$block,$area,$city,$gender,$ex,$salary,$image,$subjects,$area_covered,$medium,$class);
?>






<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
 

    
    <?php
    while($stmt->fetch()){
        ?>
        <div class="container" border=3px >
           <div class="card" style="width:300px;height:700px;" id='box' >
            <div style="width:1100px"  >
            <img class="card-img-top" >
          <?php
          
          echo '<img style="width:190px;height:150px;" src="data:image/jpeg;base64, '.base64_encode($image).'">';
              
            ?>
          
      <h4 class="card-title"><?php 
            echo $username;
            ?></h4>
          
          <?php 
            
            ?>
           <p class="card-text"><?php echo  'Email:'.$email ?></p>

            
              <p class="card-text"><?php echo  'Preferred Class:'.$class ?></p>
               <p class="card-text"><?php echo  'Medium:'.$medium ?></p>
                <p class="card-text"><?php echo  'subjects:'.$subjects ?></p>
                 <p class="card-text"><?php echo  'Area-covered'.$area_covered ?></p>
               <p class="card-text"><?php echo '<b>Experience:</b>'.$ex ?></p>
                  <p class="card-text"><?php echo  'Gender:'.$gender ?></p>
                  <p class="card-text"><?php echo  'Phone:'.$phone ?></p>
                
                   <p class="card-text"><?php echo  'salary range:'.$salary ?></p>
                   <?php
            echo 
            
               "&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <a href='tp2.php?var=$r_id' class='btn btn-primary' onclick='myFunction()'> " ."create this profile"."</a> " ."<br>";
              
            
            ?>
             </div>
          </div>
        </div> 
       <br>

          <?php
        }
      
    ?>
    <script>
function myFunction() {
  alert("successfully added into tutor list and deleted from tutors' request list");

}
</script>
 
  
  <br>
  
  

</body>
</html>

</html></p>
                </div>

                




</p>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="about-slides owl-carousel mt-100 wow fadeInUp" data-wow-delay="600ms">
                        <img src="img/bg-img/bg-3.jpg" alt="">
                        <img src="img/bg-img/bg-2.jpg" alt="">
                        <img src="img/bg-img/bg-1.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### About Us Area End ##### -->

    
    <!-- ##### Features Area Start ##### -->

    <!-- ##### Footer Area Start ##### -->
    <footer class="footer-area">
        <div class="main-footer-area section-padding-100-0">
            <div class="container">
                <div class="row">
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="footer-widget mb-100">
                            <div class="widget-title">
                                <a href="#"><img src="img/core-img/logo2.png" alt=""></a>
                            </div>
                            <p>Cras vitae turpis lacinia, lacinia lacus non, fermentum nisi. Donec et sollicitudin est, in euismod erat. Ut at erat et arcu pulvinar cursus a eget.</p>
                            <div class="footer-social-info">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                <a href="#"><i class="fa fa-behance"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="footer-widget mb-100">
                            <div class="widget-title">
                                <h6>Usefull Links</h6>
                            </div>
                            <nav>
                                <ul class="useful-links">
                                    <li><a href="#">Home</a></li>
                                    <li><a href="#">Services &amp; Features</a></li>
                                    <li><a href="#">Accordions and tabs</a></li>
                                    <li><a href="#">Menu ideas</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="footer-widget mb-100">
                            <div class="widget-title">
                                <h6>Gallery</h6>
                            </div>
                            <div class="gallery-list d-flex justify-content-between flex-wrap">
                                <a href="img/bg-img/gallery1.jpg" class="gallery-img" title="Gallery Image 1"><img src="img/bg-img/gallery1.jpg" alt=""></a>
                                <a href="img/bg-img/gallery2.jpg" class="gallery-img" title="Gallery Image 2"><img src="img/bg-img/gallery2.jpg" alt=""></a>
                                <a href="img/bg-img/gallery3.jpg" class="gallery-img" title="Gallery Image 3"><img src="img/bg-img/gallery3.jpg" alt=""></a>
                                <a href="img/bg-img/gallery4.jpg" class="gallery-img" title="Gallery Image 4"><img src="img/bg-img/gallery4.jpg" alt=""></a>
                                <a href="img/bg-img/gallery5.jpg" class="gallery-img" title="Gallery Image 5"><img src="img/bg-img/gallery5.jpg" alt=""></a>
                                <a href="img/bg-img/gallery6.jpg" class="gallery-img" title="Gallery Image 6"><img src="img/bg-img/gallery6.jpg" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <!-- Footer Widget Area -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="footer-widget mb-100">
                            <div class="widget-title">
                                <h6>Contact</h6>
                            </div>
                            <div class="single-contact d-flex mb-30">
                                <i class="icon-placeholder"></i>
                                <p>4127/ 5B-C Mislane Road, Gibraltar, UK</p>
                            </div>
                            <div class="single-contact d-flex mb-30">
                                <i class="icon-telephone-1"></i>
                                <p>Main: 203-808-8613 <br>Office: 203-808-8648</p>
                            </div>
                            <div class="single-contact d-flex">
                                <i class="icon-contract"></i>
                                <p>office@yourbusiness.com</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bottom-footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>