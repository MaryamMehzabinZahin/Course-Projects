


<?php

$src1= $_GET['var'];
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "hometutor";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>tutorcontact</title>
	<style>
		 td{
			/*border: 1px solid black;
			border-collapse: collapse;*/

			padding: 2px 5px;
			color: navy;
		}
	</style>
</head>
<body>

      <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                	<h3> information that you searched for</h3>
	
	
	<table >
		<tr>
			<th>name</th>
			<th>email</th>&nbsp &nbsp &nbsp
			
			<th>Phone</th>
		</tr>
		<?php
			//Using POST
//$src = $_POST['search'];
			
			//	if(is_numeric($_POST['search'])){
				//	$src = (int)$_POST['search'];
			//	}
			//	else{
			//		$src = $_POST["search"];
			//	}
				$stmt = $conn->prepare("select distinct username, email,phone,road,block,area,city from tutor_req1
				where userName = '$src1' ");
			
/*$stmt = $conn->prepare("select  distinct drugname from review 
				where drugName like '$src%' ");
*/


				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();
			$stmt->bind_result($username, $email,$phone,$road,$block,$area,$city);




				while($stmt->fetch()){

			?>

					<tr>
					<?php
                  echo 
						"<td>".$username."</td>".
						"<td>".$email."</td>".
						

						"<td>".$phone."</td>";
												?>
					</tr>
					<?php
				}

			
		?>


		</table>
<br><br><br><br><br><br>

<div>

	<!-- <?php
    
            if(isset($_SESSION['username'])){
                $user=$_SESSION['username'];


  echo
   "<script type=\"text/javascript\">
document.getElementById('myDIV').style.display = 'none';
document.getElementById('btn_review').style.display = 'block';



       </script>    
  ";
  echo  
"
    <h2 style='color:navy'>Hello $user !</h2>
         <div>
<a href='./logout.php'>Logout</a>
</div>
 
  ";

  }
            ?> --></div>
 
            
        </div>
    </section>
    
   
	
    <style>
        #map {
            height: 300px;
            width: 800px;
        }
    </style>
    <h3><center>See us in Google map</center>  </h3>
    <div id="map"></div>

    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script>
    	var r='<?php echo $road ;?>';
    	var b='<?php echo $block ;?>';
    	
    	/*var a='<?php echo $area ;?>';*/
    	var c='<?php echo $city ;?>';
    	var a=mirpur;
    	
    	window.alert(a);
        function area() {
            var location = "'a',dhaka , Bangladesh";
           /* var location="south badda,Dhaka, Bangladesh";*/
            return location;
        }
    </script>

    <script src="googlemap.js"></script>

    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAcNrI8A1S4IInSiDqN730I5moq-Hv-k88&callback=initMap">
    </script>

</body>
</html>

 <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
    <!-- Google Maps -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAwuyLRa1uKNtbgx6xAJVmWy-zADgegA2s"></script>
    <script src="js/google-map/map-active.js"></script>  

