

<?php

	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "hometutor";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>
	 <link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <link rel="stylesheet" type="text/css" href="Styles/s1.css" />
        <link rel="stylesheet" type="text/css" href="Styles/s2.css" />
	
	<style>
		table, th, td{
			border: 1px solid black;
			border-collapse: collapse;
			padding: 2px 5px;
		}
	</style>
</head>
<body>

    <!-- Header Area Starts -->
   
 
     
      <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                	<h1>teacher Names</h1>

		<?php
			
				

	$stmt = $conn->prepare("select username, password,email,road,block,area,city,education,dob,gender,phone,tr,ex,image from tutor_req1");
				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();
			$stmt->bind_result( $username, $password,$email,$road,$block,$area,$city,$education,$dob,$gender,$phone,$tr,$ex,$image);
?>








<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
 

  	
  	<?php
    while($stmt->fetch()){
				?>
				<div class="container" border=2px>
					 <div class="card" style="width:200px;height:400px;">
						<img class="card-img-top" style="width:100%">
					<?php
					
				    
					echo '<img style="width:190px;height:150px;" src="data:image/jpeg;base64, '.base64_encode($image).'">';
					    
						?>
					
					
						
						
					<div class="card-body">
      <h4 class="card-title"><?php 
						echo $username;
						?></h4>
					
					<?php 
						
						?>
						 <p class="card-text"><?php echo  'Qulification:'.$education ?></p>
						 	 <p class="card-text"><?php echo '<b>Experience:</b>'.$ex ?></p>
						 
<?php
						echo 
						
					     "<a href='tutorcontact.php?var=$username' class='btn btn-primary' > " ."see contact info"."</a> " ."<br>";
					    
						
						?>

      


					</div>
						</div>

    
  </div>
<br> <br>
					<?php
				}
			
		?>
	
  <br>
  
  

</body>
</html>


				



</html>



