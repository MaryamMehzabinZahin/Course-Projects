<?php 
session_start();	
if(!$_GET["usrname"]){
	header("Location: ./glogin.php");
}

$typ_username = $_GET['usrname'];
$typ_pass = $_GET['pass'];
$rememberme = $_GET['rememberme'];


$link = mysqli_connect("localhost", "root", "", "hometutor");

if(!$link){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

		if($rememberme == 'check')
		{
			
			setcookie('name',$typ_username,time() + 86400);
		
		}
	

$QRY = "select password from guardian where username = '$typ_username'  ";

$result = $link->query($QRY);

$stmt = $link->prepare($QRY);
				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();

			$stmt->bind_result($password);

			$stmt->fetch();

$salt ="$7@asdasdqwer_ojkjgjftygxwqwrtfiksdfghjkxcvbnm";
$encrypt_pass = crypt($typ_pass, $salt);

if($encrypt_pass==$password){
	
 
	$_SESSION['username'] = $typ_username;
	header("Location: ./index.php");
}
		

else{
		header("Location: ./glogin.php");
}

// when successfull login then 
// if(qr_db_pass == $_GET["usrname"])
// 	successfull login
// $session['username'] = $_GET["usrname"];
?>