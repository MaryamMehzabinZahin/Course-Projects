
<!DOCTYPE html>
<html>
<head>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<title>Login </title>
</head>





<?php
$t_id = $_GET['t_id'];
$review = $_GET['review'];
$rate = $_GET['rating'];

 echo $rate ;
for ($x = 0; $x < $rate; $x++) {
    echo '<i class="material-icons md-18">*</i>';
}

?>