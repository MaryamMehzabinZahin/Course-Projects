


<?php

$src1= $_GET['var'];
	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "hometutor";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>

   <link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <link rel="stylesheet" type="text/css" href="Styles/s1.css" />
        <link rel="stylesheet" type="text/css" href="Styles/s2.css" />
  <title> </title>
  <style>
    table, th, td{
      border: 1px solid black;
      border-collapse: collapse;
      padding: 2px 5px;
    }
  </style>

	<title>tutorcontact</title>
	<style>
		 td{
			/*border: 1px solid black;
			border-collapse: collapse;*/

			padding: 2px 5px;
			color: navy;
		}
	</style>
</head>
<body>

      <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                	<h3> information that you searched for</h3>
	
	
	
		<?php
			$stmt = $conn->prepare("select distinct username, r_id,email,phone,road,block,area,city,gender,ex,salary,image,subjects,area_covered,medium,class from tutor_req1
				where userName = '$src1' ");
			

				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();
			$stmt->bind_result($username, $r_id,$email,$phone,$road,$block,$area,$city,$gender,$ex,$salary,$image,$subjects,$area_covered,$medium,$class);


				while($stmt->fetch()){

			?>
<div class="container" border=2px>
					 <div class="card" style="width:200px;height:750px;">
						<img class="card-img-top" >
					<?php
					
					echo '<img style="width:190px;height:150px;" src="data:image/jpeg;base64, '.base64_encode($image).'">';
					    
						?>
					
      <h4 class="card-title"><?php 
						echo $username;
						?></h4>
					
					<?php 
						
						?>
						 <p class="card-text"><?php echo  'Email:'.$email ?></p>

						
						  <p class="card-text"><?php echo  'Preferred Class:'.$class ?></p>
						   <p class="card-text"><?php echo  'Medium:'.$medium ?></p>
						    <p class="card-text"><?php echo  'subjects:'.$subjects ?></p>
						     <p class="card-text"><?php echo  'Area-covered'.$area_covered ?></p>
						 	 <p class="card-text"><?php echo '<b>Experience:</b>'.$ex ?></p>
						 	    <p class="card-text"><?php echo  'Gender:'.$gender ?></p>
						 	    <p class="card-text"><?php echo  'Phone:'.$phone ?></p>
						 	  
						 	     <p class="card-text"><?php echo  'salary range:'.$salary ?></p>
						 
<?php
						echo 
						
					     "<a href='createprofile.php?var=$r_id' class='btn btn-primary' > " ."Add profile"."</a> " ."<br>";
					     echo
					      "<a href='delete.php?var=$r_id' class='btn btn-primary' > " ."delete profile"."</a> " ."<br>";



					    
						
						?>

					</div>
				</div> 
				<br>
				<br>
				<br>

						

					<?php
				}
			
		?>
	
  <br>
  
  

</body>
</html>
   	
    <style>
        #map {
            height: 300px;
            width: 800px;
        }
    </style>
    <h3><center>See us in Google map</center>  </h3>
    <div id="map"></div>

    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script>
    	
    	
        function area() {
            var location = "<?php echo $road.','.$block.','.$city;?>";
           /* var location="south badda,Dhaka, Bangladesh";*/
            return location;
        }
    </script>

    <script src="googlemap.js"></script>

    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAcNrI8A1S4IInSiDqN730I5moq-Hv-k88&callback=initMap">
    </script>


 <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
    <!-- Google Maps -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAwuyLRa1uKNtbgx6xAJVmWy-zADgegA2s"></script>
    <script src="js/google-map/map-active.js"></script>  

