<?php include 'hd1.php'; ?>

<style type="text/css">
#box {
  
  
  width:500px;
  margin: auto;
  border: 3px solid #73AD21
}
</style>

    <!-- ##### Breadcumb Area Start ##### -->
    <div class="breadcumb-area bg-img" style="background-image: url(img/bg-img/breadcumb.jpg);">
        <div class="bradcumbContent">
            <h2>Search result</h2>
        </div>
    </div>
    <!-- ##### Breadcumb Area End ##### -->

    <!-- ##### About Us Area Start ##### -->
    <section class="about-us-area mt-100 section-padding-100">
        <div class="container" id="box">
          
                <div style="width:1100px"  >
<?php

	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "hometutor";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

      

		<?php
			
				

	$stmt = $conn->prepare("select username, email,salary,road,block,area,city,area_covered,medium,class,subjects,education,dob,gender,phone,tr,ex,salary,image,r_id from tutor_req1");
			

				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);


				$stmt->execute();
			$stmt->bind_result( $username, $email,$salary,$road,$block,$area,$city,$area_covered,$medium,$class,$sub,$education,$dob,$gender,$phone,$tr,$ex,$salary,$image,$r_id);
		
		




?>







<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
 

  	
 

  	
  	<?php
    while($stmt->fetch()){
				?>
				<div class="container" border=2px>
					 <div class="card" style="width:200px;height:900px;">
						<img class="card-img-top" >
					<?php
					
					echo '<img style="width:190px;height:150px;" src="data:image/jpeg;base64, '.base64_encode($image).'">';
					    
						?>
					
      <h4 class="card-title"><?php 
						echo $username;
						?></h4>
					
					<?php 
						
						?>
						 <p class="card-text"><?php echo  'Email:'.$email ?></p>

						 <label><?php echo  'Qulification:'.$education ?></label>
						  <p class="card-text"><?php echo  'Preferred Class:'.$class ?></p>
						   <p class="card-text"><?php echo  'Medium:'.$medium ?></p>
						    <p class="card-text"><?php echo  'subjects:'.$sub ?></p>
						     <p class="card-text"><?php echo  'Area-covered'.$area_covered ?></p>
						 	 <p class="card-text"><?php echo '<b>Experience:</b>'.$ex ?></p>
						 	  <p class="card-text"><?php echo  'Date of Birth:'.$dob ?></p>
						 	   <p class="card-text"><?php echo  'Gender:'.$gender ?></p>
						 	    <p class="card-text"><?php echo  'Phone:'.$phone ?></p>
						 	     <p class="card-text"><?php echo  'bKash:'.$tr ?></p>
						 	     <p class="card-text"><?php echo  'salary range:'.$salary ?></p>
						 
<?php
						echo 
						
					     "<a href='createprofile.php?var=$r_id' class='btn btn-success'   > " ."Add profile"."</a> " ;
					     echo
					      "<a href='delete.php?var=$r_id' class='btn btn-danger' onclick='myFunction()'> " ."delete profile"."</a> " ."<br>";

					    
						
						?>








					</div>
				</div> 
				<br>
				<br>
				<br>

						

					<?php
				}
			
		?>
<script>
function myFunction() {
  alert("successfully deleted from tutors' request list");

}
	
   <br>
  
  

</body>
</html>


				



</html>
   </p>

                </div>
                
        </div>
    </section>

<?php include 'footer.php'; ?>