
<?php  
// include 'hd1.php';
$t_id = $_GET['tid'];
$g_id = $_GET['gid'];
$rv = $_GET['rv'];
$rate = $_GET['rt'];
?>




<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.checked {
  color: orange;
}
</style>

    

  
</head>



<!DOCTYPE html>
<html>
<head>
<!-- Font Awesome Icon Library -->

</head>
<body>
  <body>  
 <div class="breadcumb-area bg-img" style="background-image: url(img/bg-img/breadcumb.jpg);">
        <div class="bradcumbContent">
            <h2>See Full Information</h2>
        </div>
    </div>
    <!-- ##### Breadcumb Area End ##### -->

    <!-- ##### About Us Area Start ##### -->
    <section class="about-us-area mt-50 section-padding-100">
        <div class="container" >
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center mx-auto wow fadeInUp" data-wow-delay="300ms">
                        <span>The Best</span>
                          <h1>Hometutors.com </h1>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-6 wow fadeInUp" data-wow-delay="400ms" >
  <div class="container">
 
  
  <div class="card" style="width:400px">
   
    <div class="card-body">
    
      <h3 class="card-text">Tutor ID: <?php echo $t_id; ?></h3><br>
       <h3 class="card-text"> Review:<?php echo $rv; ?></h3><br>
       <h3 class="card-text">Rating:
         
<?php



for ($x = 0; $x < $rate; $x++) {
    echo '
    <span class="fa fa-star checked"></span>
    ';
}
for ($x1 = 5; $x1 >$rate; $x1--) {
    echo '
    <span class="fa fa-star "></span>
    ';
}

$dbcon=mysqli_connect("localhost", "root", "", "hometutor");
       
        $qry="INSERT INTO review (t_id,g_id,review,rating)
 VALUES ('$t_id', '$g_id','$rv','$rate')";

    
        if(mysqli_query($dbcon,$qry))
        {
          
            
        }
        else
        { echo " error ";
        }



?>


       </h3><br>
      
  </div>
  <br>
  
  
</div>
</div>
</div>
 <div class="col-12 col-md-6 wow fadeInUp" data-wow-delay="400ms" >
  <h1 style="color: green">Thanks for the review!!!!</h1>
  </div>
</div>
</div>
</section>


</body>
</html>







</body>
</html>