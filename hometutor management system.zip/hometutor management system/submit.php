<?php 
session_start();	
if(!$_GET["g_id"]){
	header("Location: ./login.php");
}
$typ_username= $_GET['username'];
$typ_id = $_GET['g_id'];
$typ_pass = $_GET['pass'];
$rememberMe = $_GET['rememberMe'];



$link = mysqli_connect("localhost", "root", "", "hometutor");

if(!$link){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

		if($rememberme == 'check')
		{
			
			setcookie('name',$typ_id,time() + 86400);
		
		}
	

$QRY = "select password from user where g_id = '$typ_id'  ";

$result = $link->query($QRY);

$stmt = $link->prepare($QRY);
				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();

			$stmt->bind_result($password);

			$stmt->fetch();


if($typ_pass==$password){
	
 

	$_SESSION['username'] = $typ_username;
	$_SESSION['g_id']=$g_id;
	header("Location: ./review.php");
}
		


else{
	header("Location: ./login1.php");	
}

// when successfull login then 
// if(qr_db_pass == $_GET["usrname"])
// 	successfull login
// $session['username'] = $_GET["usrname"];
?>