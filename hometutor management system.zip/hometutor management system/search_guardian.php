



<?php

	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "hometutor";

	$conn = new mysqli($server, $username, $password, $database);

	if($conn->connect_error){
		die("Connecntion Failed: " . $conn->connect_error);
	}
	else{
		//echo "Connencted Succesfully";
	}
?>

<!DOCTYPE html>
<html>
<head>
	 <link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <link rel="stylesheet" type="text/css" href="Styles/s1.css" />
        <link rel="stylesheet" type="text/css" href="Styles/s2.css" />
	<title>PHP Lab Exercise 3</title>
	<style>
		table, th, td{
			border: 1px solid black;
			border-collapse: collapse;
			padding: 2px 5px;
		}
	</style>
</head>
<body>

    <!-- Header Area Starts -->
   
 
     
      <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                	<h1>teacher Names</h1>

		<?php
			//Using POST
$src = $_GET['search'];
			
			//	if(is_numeric($_POST['search'])){
				//	$src = (int)$_POST['search'];
			//	}
			//	else{
			//		$src = $_POST["search"];
			//	}
				$stmt = $conn->prepare("select distinct username from tutor_req1
				where area like '$src%' ");
				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				$stmt->execute();
			$stmt->bind_result( $username);


while($stmt->fetch()){
				?>
					<tr>
					<?php
						echo 
						
					   $username;
					    
						
						?>
					</tr>
					<?php
				}
			
		?>

				

</body>

</html>



