<!DOCTYPE html>
<html>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
.error {color: #FF0000;}
input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
<body>


</body>

<?php



$name = $email = $gender = $comment =$gender= $website =$pass=$add= $d=$a=$n=$phone=$ed=$city=$rd=$bd=$ad=$salary=$image="";
$nameErr = $emailErr = $genderErr = $websiteErr =$passErr=$addErr=$dErr=$nErr=$tr= $ex=$salaryErr="";
$ck=0;
$Reg = '[a-z]{2,6}$/i';
$f=0;
$c=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]{6,15}$/i",$name)) {
      $nameErr = "Username must be 6-15 chars long"; 
  }
  else
  {
    $ck++;
  }
}
if (empty($_POST["phone"])) {
    $nErr = "number is required";
  } else {
    $phone = test_input($_POST["phone"]);
    if (!preg_match('/^01[3-9]{1}\d{8}$/', $phone)) {
         $nErr = "number of course enrolled should contain only integer";
          }
        
             else
  {
    $ck++;
  }
        }


      

        

  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format"; 
    }
     else
  {
    $ck++;
  }
  }

  if (empty($_POST["pass"])) {
    $passErr = "pass is required";
  } else {
    $pass = test_input($_POST["pass"]);
    if (!preg_match("/\d/", $pass)) {
         $passErr = "Password should contain at least one number";
          }
        else  if (!preg_match("/[A-Z]/", $pass)) {
            $passErr = "Password should contain at least one uppercase Letter";
          }
         else if (!preg_match("/[a-z]/", $pass)) {
            $passErr= "Password should contain at least one lowercase Letter";
          }
        else
  {
    $ck++;
  }
          
  }

  
 




if (empty($_POST["d"])) {
    $dErr = "date is required";
  } else {
    $d = $_POST["d"];

 
//Create a DateTime object using the user's date of birth.
$dob = new DateTime($d);
 
//We need to compare the user's date of birth with today's date.
$now = new DateTime();
 
//Calculate the time difference between the two dates.
$difference = $now->diff($dob);
 
//Get the difference in years, as we are looking for the user's age.
$age = $difference->y;
 
//Print it out.
if ($age<15)
{
  $dErr = "sorry u can't enter because u r under 15 ";
}
 else
  {
    $ck++;
  }

}
}

 
 


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}




     
       $name=$_POST['name'];
  $email=$_POST['email'];
  
  $phone=$_POST['phone'];
  $pass=$_POST['pass'];
 
 
 
?>


<form method="post" action="index.php" style="border:1px solid #ccc">
  <div class="container">
    <h1>Guardian Sign Up</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>

    <label style="color: red"><b>Username</b></label><span class="error">*
    <input type="text" placeholder="Enter Name" name="name"  value="<?php echo $name;?>" required> <?php echo $nameErr;?>
     <?php echo $passErr;?>

    <label ><b>Password</b></label><span class="error">*
    <input type="password" placeholder="Enter Password" name="pass" value="<?php echo $pass;?>" required>

    
    <label ><b>Email</b></label><span class="error">*
    <input type="text" placeholder="Enter Email" name="email" required value="<?php echo $email;?>" required>
        <?php echo $emailErr;?>
    <label ><b>Date of Birth:</b></label><span class="error">*
    <input type="text" placeholder="Enter Date of birth" name="d" required>
     <?php echo $dErr;?>

    
      <label ><b>Phone:</b></label><span class="error ">*
    <input type="text" placeholder="Enter Phone Number" name="d" value="<?php echo $phone;?>" required>
    <?php echo $nErr;?>
     

    
    <label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label>
    
    <p>By creating an account you agree to our <a href="terms.php" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
      <button type="button" class="cancelbtn">Cancel</button>
      <button type="submit" class="signupbtn">Sign Up</button>
    </div>
  </div>
</form>





</html>
 