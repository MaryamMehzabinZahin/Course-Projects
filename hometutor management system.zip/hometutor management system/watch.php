<html>
<body>
<?php
$con = mysqli_connect('localhost','root','','hometutor') or die('Connection error!');

  if(isset($_GET['id']))
  {
$id=$_GET['id'];
$q="select video from course where id=$id";
$query =mysqli_query($con,$q);
while($row=mysqli_fetch_assoc($query))
{
	  $name =$row['video'];
	  
}

echo "id: ".$id;

echo " and video:  ".$name."<br>";
echo "<video width='400' controls><source src=' ".$name."' type='video/webm'></video>";
  }
  else{
	  echo "Eroor!";
  }
  ?>
  </body>
  </html>