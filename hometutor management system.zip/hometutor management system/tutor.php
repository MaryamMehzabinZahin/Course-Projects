<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  

<?php
// define variables and set to empty values
$nameErr = $emailErr = $genderErr = $websiteErr =$passErr=$addErr=$dErr=$nErr=$bKashErr= "";
$name = $email = $gender = $comment = $website =$pass= $d=$a=$n=$bKash=  "";
$Reg = '[a-z]{2,6}$/i';
$f=0;
$c=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]{6,15}$/i",$name)) {
      $nameErr = "Username must be 6-15 chars long"; 
    }
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format"; 
    }
  }
  if (empty($_POST["pass"])) {
    $passErr = "pass is required";
  } else {
    $pass = test_input($_POST["pass"]);
    if (!preg_match("/\d/", $pass)) {
         $passErr = "Password should contain at least one number,one uppercase Letter,one lowercase Letter,one spec char";
          }
          if (!preg_match("/[A-Z]/", $pass)) {
            $passErr ="Password should contain at least one number,one uppercase Letter,one lowercase Letter,one spec char";
          }
          if (!preg_match("/[a-z]/", $pass)) {
            $passErr= "Password should contain at least one number,one uppercase Letter,one lowercase Letter,one spec char";
          }
          if(!preg_match("/\./", $pass)){
            $f=1;
            
          }
          else
          {
            $c++;
          }
          if(!preg_match("/\?/", $pass)){
            $f=1;
          
          }
          else
          {
            $c++;
          }
          if(!preg_match("/\+/", $pass)){
            $f=1;
        
          }
          else
          {
            $c++;
          }
          if(!preg_match("/\*/", $pass)){
            $f=1;
        
          }
          else
          {
            $c++;
          }
        
         if($c==0) 
          {
             $passErr= "Password should contain at least one number,one uppercase Letter,one lowercase Letter,one spec char";
          }
          
  }
  
  if (empty($_POST["bKash"])) {
    $bKashErr = "bKash number is required";
  }
  else{
	  $bKash = test_input($_POST["bKash"]);
  if(!preg_match('/^01[3-9]{1}\d{8}$/', $bKash)){
		  $bKashErr = "NOT a valid bKash";
	  }
	  
  }

  
  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }

  if (empty($_POST["a"])) {
    $addErr = "adress is required";
  } else {
    $a = test_input($_POST["a"]);
  }
  if (empty($_POST["d"])) {
    $dErr = "date is required";
  } else {
    $d = $_POST["d"];

 
//Create a DateTime object using the user's date of birth.
$dob = new DateTime($d);
 
//We need to compare the user's date of birth with today's date.
$now = new DateTime();
 
//Calculate the time difference between the two dates.
$difference = $now->diff($dob);
 
//Get the difference in years, as we are looking for the user's age.
$age = $difference->y;
 
//Print it out.
if ($age<15)
{
  $dErr = "sorry u can't enter because u r under 15 ";
}

}
}
        
 
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


?>

<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  

 <table>
		<tr>
		<td> Username:</td>
		<td><input type="text" name="name" value="<?php echo $name;?>"></td>
  <td><span class="error">* <?php echo $nameErr;?></span></td></tr>
 
  <tr>
  <td>Password:</td>
<td>  <input type="text" name="pass" value="<?php echo $pass;?>"></td>
 <td><span class="error">* <?php echo $passErr;?></span></td></tr>
  
  <tr>
 <td> Email: </td>
 <td><input type="text" name="email" value="<?php echo $email;?>"></td>
  <td><span class="error">* <?php echo $emailErr;?></span></td></tr>
  
  <tr>
 <td> Address:</td>
<td> <input type="text" name="a" value="<?php echo $a;?>"></td>
  <td><span class="error">* <?php echo $addErr;?></span></td></tr>
  
  <tr>
  <td>Date of Birth:</td>
<td>  <input type="text" name="d" value="<?php echo $d;?>"></td>
  <td><span class="error">* <?php echo $dErr;?></span></td></tr>
  
   <tr>
  <td>bKash number:</td>
<td>  <input type="tel" name="bKash" value="<?php echo $bKash;?>"></td>
 <td><span class="error">* <?php echo $bKashErr;?></span></td></tr>
  
 
 <tr>
 <td> Gender:</td>
  <td><input type="radio" name="gender" <?php if (isset($gender) && $gender=="female") echo "checked";?> value="female">Female
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="male") echo "checked";?> value="male">Male
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="other") echo "checked";?> value="other">Other  </td>
  <td><span class="error">* <?php echo $genderErr;?></span></td></tr>
  
 
<tr>
<td> <input type="submit" name="submit" value="Register"> </td></tr>  
</table> 
</form>



</body>
</html>