<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!-- Title -->
    <title>Academy - Education Course Template</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">





</head>

<body>
    <!-- ##### Preloader ##### -->
    <div id="preloader">
        <i class="circle-preloader"></i>
    </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area">

        <!-- Top Header Area -->
        <div class="top-header">
            <div class="container h-100">
                <div class="row h-100">
                    <div class="col-12 h-100">
                        <div class="header-content h-100 d-flex align-items-center justify-content-between">
                            <div class="academy-logo">
                                <a href="index.html"><img src="img/core-img/logo.png" alt=""></a>
                            </div>
                            <div class="login-content">
                               
                                  <?php
                         
            if(isset($_SESSION['username'])){
                $user=$_SESSION['username'];
  
echo "
      <span class='glyphicon glyphicon-user' style='color:blue'> 
      <a style='color:blue' href='./profile.php'>
      $user";
  
             ?>
         <?php
         echo "</a>";
           echo "&nbsp &nbsp &nbsp";
           echo "<a style='color:red' href='logout.php'>logout</a>";
          
       }

       
         ?>
         
        
         <?php
          if(!isset($_SESSION['username']))
            {

              echo "<a style='color:blue' href='logreg.php'>Register / Login</a>";
               echo
   "<script type=\'text/javascript\''>

document.getElementById('btn_review').style.display = 'block';
 
       </script>    
  ";  

        
            }
             
           

             ?>
                                
                                
                            </div>
                          
                </div>
            </div>
        </div>

        <!-- Navbar Area -->
        <div class="academy-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="academyNav">

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- close btn -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="#">Pages</a>
                                        <ul class="dropdown">
                                            <li><a href="index.php">Home</a></li>
                                            <li><a href="about.php">About Us</a></li>
                                            <li><a href="course.php">Course</a></li>
                                            
                                            <li><a href="contact.php">Contact</a></li>
                                        
                                        </ul>
                                    </li>
                                   
                                   <li><a href="about.php">About Us</a></li>
                                    <li><a href="course.php">Course</a></li>
                                    <li><a href="contact.php">Contact</a></li>
                               
                                 <li><a href="index.php" class='dropbtn' style="color: solid green">Search Home Tutors.....</a>
                                      <ul class="dropdown">
                                            <li> <a href="test.php">Customized</a></li>
                                           
                                          
                                         

                                        </ul></li>
                                        
                                        
                                           
                                            <li><a href="review.php">Give Review</a></li>
                                          
                                         

                                        </ul></li>
                                      </div>
                                        

                            </ul>
                            <!-- Nav End -->
                        </div>

                        <!-- Calling Info -->
                        
                    </nav>
                </div>
            </div>
        </div>
    </header>

<!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>
</html>