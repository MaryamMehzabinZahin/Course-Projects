<?php include 'hd1.php' ?>
<style type="text/css">
#box {
  margin: auto;
 
  border: 3px solid black
}
</style>



    <!-- ##### Breadcumb Area Start ##### -->
    <div class="breadcumb-area bg-img" style="background-image: url(img/bg-img/breadcumb.jpg);">
        <div class="bradcumbContent">
            <h2>See Full Information</h2>
        </div>
    </div>
    <!-- ##### Breadcumb Area End ##### -->

    <!-- ##### About Us Area Start ##### -->
    <section class="about-us-area mt-50 section-padding-100">
        <div class="container" >
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center mx-auto wow fadeInUp" data-wow-delay="300ms">
                        <span>The Best</span>
                          <h1>Hometutors.com </h1>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-6 wow fadeInUp" data-wow-delay="400ms" >
                  
                    <p><?php

  $server = "localhost";
  $username = "root";
  $password = "";
  $database = "hometutor";

  $conn = new mysqli($server, $username, $password, $database);

  if($conn->connect_error){
    die("Connecntion Failed: " . $conn->connect_error);
  }
  else{
    //echo "Connencted Succesfully";
  }
?>

<!DOCTYPE html>
<html>
<head>
   <link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <link rel="stylesheet" type="text/css" href="Styles/s1.css" />
        <link rel="stylesheet" type="text/css" href="Styles/s2.css" />
  <title> </title>
  <style>
    table, th, td{
      border: 1px solid black;
      border-collapse: collapse;
      padding: 2px 5px;
    }
  </style>
</head>
<body>

    <!-- Header Area Starts -->
   
  <?php
          if(!isset($_SESSION['username']))
            {

echo '<script language="javascript">';
echo 'alert("you need to login to see the course list")';
echo '</script>';



    }
             ?>
     <?php


            
  


if(isset($_SESSION['username'])){
                $user=$_SESSION['username'];

        $sql_ = "SELECT username, email, area, city, phone FROM guardian where username='$user'";
      $stmt = $conn->prepare($sql_);
      

        //$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
        $stmt->execute();
      $stmt->bind_result($username, $email,$area,$city,$phone);
    }
    ?>
   
           

            






<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
 

    
    <?php

            if(isset($_SESSION['username'])){
                $user=$_SESSION['username'];
   
    while($stmt->fetch()){
        ?>
        <div class="container" border=3px >
           <div class="card" style="width:300px;height:350px;" id='box' >
            <img class="card-img-top" >
          <?php
        echo "  
        <span class='glyphicon glyphicon-user' style='color:blue; font-size:100px;'>";
              
            ?>
          
      <h4 class="card-title"><?php 
            echo $username;
            ?></h4>
          
          <?php 
            
            ?>
           <p class="card-text" style="font-family: verdana"><?php echo  '<b>Email:</b>'.$email ?></p>

            
                  <p class="card-text" tyle="font-family: verdana"><?php echo  '<b>Phone:</b>'.$phone ?></p>
                   <p >
                
                 
    </p>
  
                   
                   </p>
             
          </div>
        </div> 
       <br>

          <?php
        }
      }
      
    ?>
  
  <br>
  
  

</body>
</html>


    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>
