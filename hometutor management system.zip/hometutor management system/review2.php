<?php require 'hd1.php' ?>
 

 <style type="text/css">
#box {
  margin: auto;
 
  border: 3px solid black
}
</style>



    <!-- ##### Breadcumb Area Start ##### -->
    <div class="breadcumb-area bg-img" style="background-image: url(img/bg-img/breadcumb.jpg);">
        <div class="bradcumbContent">
            <h2>See Full Information</h2>
        </div>
    </div>
    <!-- ##### Breadcumb Area End ##### -->

    <!-- ##### About Us Area Start ##### -->
    <section class="about-us-area mt-50 section-padding-100">
        <div class="container" >
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center mx-auto wow fadeInUp" data-wow-delay="300ms">
                        <span>The Best</span>
                          <h1>Hometutors.com </h1>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-6 wow fadeInUp" data-wow-delay="400ms" >
                  
                    <p><?php

  $src1= $_GET['var'];
  $server = "localhost";
  $username = "root";
  $password = "";
  $database = "hometutor";

  $conn = new mysqli($server, $username, $password, $database);

  if($conn->connect_error){
    die("Connecntion Failed: " . $conn->connect_error);
  }
  else{
    //echo "Connencted Succesfully";
  }
?>

<!DOCTYPE html>
<html>
<head>
   <link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
     <link rel="stylesheet" type="text/css" href="Styles/s1.css" />
        <link rel="stylesheet" type="text/css" href="Styles/s2.css" />
  <title> </title>
  <style>
    table, th, td{
      border: 1px solid black;
      border-collapse: collapse;
      padding: 2px 5px;
    }
  </style>
</head>
<body>

    <!-- Header Area Starts -->
  
     <?php


          
      $stmt = $conn->prepare("select distinct review_id,t_id,review,rating  from review
        where t_id = '$src1' ");
      

        //$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
        $stmt->execute();
      $stmt->bind_result($review_id, $t_id,$review,$rating);
    
    ?>
  

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>



    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.checked {
  color: orange;
}
</style>

    

  

</head>
<body>
 

    
    <?php

           
   
    while($stmt->fetch()){
        ?>
         <div class="row">
                <div class="col-12 col-md-6 wow fadeInUp" data-wow-delay="400ms" >
  <div class="container">
 
  
  <div class="card" style="width:400px">
   
    <div class="card-body">
    
      <h3 class="card-text">Tutor ID: <?php echo $t_id; ?></h3><br>
      <h3 class="card-text">Review ID: <?php echo $review_id; ?></h3><br>
       <h3 class="card-text"> Review:<?php echo $review; ?></h3><br>
       <h3 class="card-text">Rating:
         
<?php



for ($x = 0; $x < $rating; $x++) {
    echo '
    <span class="fa fa-star checked"></span>
    ';
}
for ($x1 = 5; $x1 >$rating; $x1--) {
    echo '
    <span class="fa fa-star "></span>
    ';
}




?>


       </h3><br>
      
  </div>
  <br>
  
  
</div>
</div>
</div>
 
</div>
</div>
</section>


</body>
</html>

     
          
         
             
          </div>
        </div> 
       <br>

          <?php
        
      }
      
    ?>
  
  <br>
  
  

</body>
</html>


 <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
    <!-- Google Maps -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAwuyLRa1uKNtbgx6xAJVmWy-zADgegA2s"></script>
    <script src="js/google-map/map-active.js"></script>  




</p>
</div>
</div>
</div>
</section>


</html>