<?php include 'hd1.php'; ?>

<?php
			
$gender= $_GET['gender'];
$stmt = $conn->prepare("select username,education,gender,ex,salary,image,subjects,area_covered,medium,class from tutor
	where gender='$gender'  ");

				//$stmt->bind_param("ssi", $_POST["name"], $_POST["subject"], $_POST["mark"]);
				

				$stmt->execute();
			$stmt->bind_result( $username, $education,$gender,$ex,$salary,$image,$subjects,$area_covered,$medium,$class);
            if(empty($stmt->bind_result))
            {

                echo "not found";
            }
			

?>




				<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
 

  	
  	<?php
    while($stmt->fetch()){
				?>
				<div class="container" border=2px>
					 <div class="card" style="width:200px;height:700px;">
						<img class="card-img-top" style="width:100%">
					<?php
					
				    
					echo '<img style="width:190px;height:150px;" src="data:image/jpeg;base64, '.base64_encode($image).'">';
					    
						?>
					
					
						
						
					<div class="card-body">
      <h4 class="card-title"><?php 
						echo $username;
						?></h4>
					
					<?php 
						
						?>
						 <p class="card-text"><?php echo  'Tutor ID:'.$r_id ?></p>
						  <p class="card-text"><?php echo  'Qulification:'.$education ?></p>
						 	
						 <p class="card-text"><?php echo  'Preferred Class:'.$class ?></p>
						   <p class="card-text"><?php echo  'Medium:'.$medium ?></p>
						    <p class="card-text"><?php echo  'subjects:'.$sub ?></p>
						     <p class="card-text"><?php echo  'Area-covered'.$area_covered ?></p>
						 	 <p class="card-text"><?php echo '<b>Experience:</b>'.$ex ?></p>
						 	 
						 	   
						 	     <p class="card-text"><?php echo  'salary range:'.$salary ?></p>
<?php
						echo 
						
					     "<p><a href='test2.php?var=$r_id' class='btn btn-primary' > " ."see contact info"."</a> " ."<br>";
					    
					
					    
						
						?>

      


					</div>
						</div>

    
  </div>
<br> <br>
					<?php
				}
			
		?>
	
  <br>
  
  

</body>
</html>

