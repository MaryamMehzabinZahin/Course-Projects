
<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}

  .graybox {
    background-color: #f2f1e3;
    border: 1px solid #d3ceb4;
    padding: 10px;
  }
  .dbox {
    background-color:   #f7f9f9;
    padding: 10px;
  }

    .tab-border {
    text-align: center;
    border: 1px solid black;
  }
</style>
</head>
<body>  

<?php



$name = $email = $gender = $comment =$gender= $website =$pass=$add= $d=$a=$n=$phone=$ed=$city=$rd=$bd=$ad=$salary=$gid=$tid="";
$nameErr = $emailErr = $genderErr = $websiteErr =$passErr=$addErr=$dErr=$nErr=$tr= $ex=$salaryErr="";
$ck=0;
$Reg = '[a-z]{2,6}$/i';
$f=0;
$c=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["gid"])) {
    $nameErr = "gid is required";
  } else {
    $gid = $_POST["gid"];
    
    $ck++;
  }

if (empty($_POST["tid"])) {
    $nameErr = "tid is required";
  } else {
    $tid = $_POST["tid"];
    
    $ck++;
  }
}
 
 

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


  
     if($ck==2)
     {
     $gid = $_POST["gid"];
     $tid = $_POST["tid"];
       
        $qry="INSERT INTO review (gid,tid,rv,rt)
 VALUES ('$name', '$pass', '$email','$rd','$bd','$ad','$city','$ed','$d','$gender','$phone','$tr','$ex','$salary','$image')";

    
        if(mysqli_query($dbcon,$qry))
        {
            echo " <br/>Image uploaded.";
            
        }
        else
        { echo " error ";
        }
    }
?>


<div class="row">
    <div class="col-sm-4" >
      
    </div>
    <div class="col-sm-6" >
      <div class="container">
        
        <div class="container">
        
<p><span class="error">* required field</span></p>
<form method="post" action="" enctype="multipart/form-data"> 
  <table>
  <tr>
  <td>Guardian ID:       </td>
  <td><input type="text" name="gid" value="<?php echo $name;?>" ></td>
  <td><span class="error">* <?php echo $nameErr;?></span></td></tr>
  <br>
 <tr>
  <td>   Tutor ID: </td>
  <td><input type="text" name="tid" value="<?php echo $pass;?>"></td>
  <td><span class="error">* <?php echo $passErr;?></span></td></tr>
  <br>
  <tr>
 <td> Rating</td>
 <td> <input type="text" name="rt"> </td>
  <td><span class="error">* <?php echo $emailErr;?></span></td></tr>
  <br>
  
<tr><td>Review</td>
  <td><input type="textarea" name="rv"></td>
   </tr>
 

 <tr><td><input type="submit" name="submit" value="submit" style="color: red">    </td></tr>
</table>
</form>

</div>
</div>
</div>


</body>
</html>