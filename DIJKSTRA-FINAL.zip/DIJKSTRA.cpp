using namespace std;
#include <stdio.h>
#include <iostream>
#include <string.h>
#include <vector>
#include <list>
#include <math.h>
#include <queue>
#include <conio.h>
#include <dos.h>
#include <stdlib.h>
#include <windows.h>
#define f 100000000
struct compare
{
  bool operator()(const int& l, const int& r)
  {
      return l > r;
  }
};
priority_queue<int,vector<int>, compare>T,C,D;
FILE *M=fopen("hello.txt","r");
FILE *N=fopen("hi.txt","w");

int n=-1,a,b,t,c,d,j;
int prev_Time[100],d_Time[100];
int prev_Cost[100],d_Cost[100];
int prev_Distance[100],d_Distance[100];

int mat_Time[100][100];
int mat_Cost[100][100];
int mat_Distance[100][100];

int flag_Time[100]={0};
int flag_Cost[100]={0};
int flag_Distance[100]={0};
///-------------------------------------------------------------

void DIJKSTRA_TIME(int SOURCE)
{

    for(int i=1;i<=n;i++)
    {
       prev_Time[i]=-1;
       d_Time[i]=f;

    }
    prev_Time[SOURCE]=-1;
    d_Time[SOURCE]=0;
    T.push(SOURCE);
    while(!T.empty())
    {
      int u=T.top();
      T.pop();
      for(int i=1;i<=n;i++)
      {
          if(mat_Time[u][i]!=0)
          {
              if(mat_Time[u][i]+d_Time[u]<d_Time[i])
              {
                d_Time[i]=mat_Time[u][i]+d_Time[u];
                prev_Time[i]=u;
                if(flag_Time[i]==0)
                {
                        T.push(i);
                        flag_Time[i]=1;
                }
              }
          }
      }
    }
}
void DIJKSTRA_COST(int SOURCE)
{

    for(int i=1;i<=n;i++)
    {
       prev_Cost[i]=-1;
       d_Cost[i]=f;
    }
    prev_Cost[SOURCE]=-1;
    d_Cost[SOURCE]=0;
    C.push(SOURCE);
    while(!C.empty())
    {
      int u=C.top();
      C.pop();
      for(int i=1;i<=n;i++)
      {
          if(mat_Cost[u][i]!=0)
          {
              if(mat_Cost[u][i]+d_Cost[u]<d_Cost[i])
              {
                d_Cost[i]=mat_Cost[u][i]+d_Cost[u];
                prev_Cost[i]=u;
                if(flag_Cost[i]==0)
                {
                        C.push(i);
                        flag_Cost[i]=1;
                }
              }
          }
      }
    }
}

void DIJKSTRA_DISTANCE(int SOURCE)
{

    for(int i=1;i<=n;i++)
    {
       prev_Distance[i]=-1;
       d_Distance[i]=f;
    }
    prev_Distance[SOURCE]=-1;
    d_Distance[SOURCE]=0;
    D.push(SOURCE);
    flag_Distance[SOURCE]=1;
    while(!D.empty())
    {
      int u=D.top();
      D.pop();
      for(int i=1;i<=n;i++)
      {
          if(mat_Distance[u][i]!=0)
          {
              if(mat_Distance[u][i]+d_Distance[u]<d_Distance[i])
              {
                d_Distance[i]=mat_Distance[u][i]+d_Distance[u];
                prev_Distance[i]=u;

                if(flag_Distance[i]==0)
                    {
                        D.push(i);
                        flag_Distance[i]=1;
                    }
              }
          }
      }
    }
}
void Print_Path_Distance(int SOURCE,int DIS)
{
	if(SOURCE==DIS)
		fprintf(N,"%d",SOURCE);
   else if(prev_Distance[DIS]==-1)
		fprintf(N,"No path");
	else
    {
		Print_Path_Distance(SOURCE,prev_Distance[DIS]);
		fprintf(N,"--%d",DIS);
	}
}
void Print_Path_TIME(int SOURCE,int DIS)
{
	if(SOURCE==DIS)
		fprintf(N,"%d",SOURCE);
   else if(prev_Time[DIS]==-1)
		fprintf(N,"No path");
	else
    {
		Print_Path_TIME(SOURCE,prev_Time[DIS]);
		fprintf(N,"--%d",DIS);
	}
}
void Print_Path_COST(int SOURCE,int DIS)
{
	if(SOURCE==DIS)
		fprintf(N,"%d",SOURCE);
   else if(prev_Cost[DIS]==-1)
		fprintf(N,"No path");
	else
    {
		Print_Path_COST(SOURCE,prev_Cost[DIS]);
		fprintf(N,"--%d",DIS);
	}
}




int main()
{
    fprintf(N,"\t\t\t###ALL TYPE OF SHORTEST PATH USING DIJKSTRA ALGORITHM###\n");
    fprintf(N,"\t\t\t--------------------------------------------------------\n\n");

    while(1){
        fscanf(M,"%d %d %d %d %d",&a,&b,&t,&c,&d);

        if(a==0 || b==0)
            break;
        mat_Time[a][b]=t;
        mat_Cost[a][b]=c;
        mat_Distance[a][b]=d;
        if(a>b && a>n)
            n=a;
        else if(b>a && b>n)
            n=b;
    }
   int x=1,y=1;
   int node;
   int des;
   printf("\n\t# SELECT A SOURCE NODE,(1-%d): ",n);
   scanf("%d",&node);
   fprintf(N,"SELECTED SOURCE NODE,(1-%d):%d\n",n,node);
   printf("\t# SELECT A DESTINAION NODE FOR FINDING SHORTEST PATH FROM : %d to ",node);
    scanf("%d",&des);
   fprintf(N,"\nSELECTED DESTINATION NODE:%d\n\n",des);


 while(1)
 {
       DIJKSTRA_TIME(node);
       DIJKSTRA_COST(node);
       DIJKSTRA_DISTANCE(node);
    if(x)
     {

    fprintf(N,"\n\t\t\tWHEN (TIME) IS ACT LIKE A WEIGHT\n");
    fprintf(N,"\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
    fprintf(N,"\t\tNODE\tPREVIOUS\tSHORTEST_DISTANCE\n");
    fprintf(N,"\t\t----\t--------\t-----------------\n");
    for(int i=1;i<=n;i++)
    {
       fprintf(N,"\t\t%d\t%d\t\t%d\n",i,prev_Time[i],d_Time[i]);
    }
    fprintf(N,"\n\t\t\tWHEN (COST) IS ACT LIKE A WEIGHT\n");
    fprintf(N,"\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
    fprintf(N,"\t\tNODE\tPREVIOUS\tSHORTEST_DISTANCE\n");
    fprintf(N,"\t\t----\t--------\t-----------------\n");
    for(int i=1;i<=n;i++)
    {
       fprintf(N,"\t\t%d\t%d\t\t%d\n",i,prev_Cost[i],d_Cost[i]);
    }
    fprintf(N,"\n\t\t\tWHEN (DISTANCE) IS ACT LIKE A WEIGHT\n");
    fprintf(N,"\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
    fprintf(N,"\t\tNODE\tPREVIOUS\tSHORTEST_DISTANCE\n");
    fprintf(N,"\t\t----\t--------\t-----------------\n");
    for(int i=1;i<=n;i++)
    {
       fprintf(N,"\t\t%d\t%d\t\t%d\n",i,prev_Distance[i],d_Distance[i]);
    }
     }
    if(y)
    {
    fprintf(N,"\t\t\tSHORTEST PATH FROM :(%d-%d)\n",node,des);
    fprintf(N,"\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    fprintf(N,"\t\tWEIGHT(TIME)\n");
    fprintf(N,"\t\t~~~~~~~~~~~\n");
    fprintf(N,"SHORTEST PATH:");Print_Path_TIME(node,des);

    fprintf(N,"\n\t\tWEIGHT(COST)\n");
    fprintf(N,"\t\t~~~~~~~~~~~\n");
    fprintf(N,"SHORTEST PATH:");Print_Path_COST(node,des);

    fprintf(N,"\n\t\tWEIGHT(DISTANCE)\n");
    fprintf(N,"\t\t~~~~~~~~~~~~~~~~\n");
    fprintf(N,"SHORTEST PATH:");Print_Path_Distance(node,des);
    }

    fclose(N);

      int p=0;
      printf("\n\tLading");
      for(;;) {
         cout<<".";
         Sleep(1500);
         p++;
        if(p==4) break;
      }
    printf("\n\t\t\n\t\tWHAT YOU WANT TO DO?\n");
    printf("\t\t~~~~~~~~~~~~~~~~~~~~\n");
    printf("1.CHANGE SOURCE NODE\n");
    printf("2.CHANGE DESTINATION NODE\n");
    printf("3.PRINT SHORTEST PATH ONLY\n");
    printf("4.PRINT SHOREST DISTENCE FROM SOURCE NODE TO OTHERs\n");
    printf("5.EXIT\n");
    int k;
    printf("\n\nYOU ARE SELECTED:");
    scanf("%d",&k);
    FILE *N=fopen("hi.txt","w");
    if(k==1)
    {
      x=1;y=1;
      printf("\nNEW SOURCE NODE:");
      scanf("%d",&node);
      fprintf(N,"\nNEW SOURCE NODE:%d",node);
      fprintf(N,"\nSELECTED DESTINATION NODE:%d\n\n",des);
    }
    else if(k==2)
    {
      x=1;y=1;
      fprintf(N,"\nSOURCE NODE:%d",node);
      printf("\nNEW DESTINATION NODE:");
      scanf("%d",&des);
      fprintf(N,"\nNEW DESTINATION NODE:%d",des);
    }
    else if(k==3)
    {
         x=0;
         y=1;
    }
    else if(k==4)
    {
        y=0;
        x=0;

        fprintf(N,"\nSOURCE NODE:%d",node);


    fprintf(N,"\n\t\t\tWHEN (TIME) IS ACT LIKE A WEIGHT\n");
    fprintf(N,"\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
    fprintf(N,"\t\tNODE\tSHORTEST_DISTANCE\n");
    fprintf(N,"\t\t----\t-----------------\n");
    for(int i=1;i<=n;i++)
    {
       fprintf(N,"\t\t%d\t\t%d\n",i,d_Time[i]);
    }
    fprintf(N,"\n\t\t\tWHEN (COST) IS ACT LIKE A WEIGHT\n");
    fprintf(N,"\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
    fprintf(N,"\t\tNODE\tSHORTEST_DISTANCE\n");
    fprintf(N,"\t\t----\t-----------------\n");
    for(int i=1;i<=n;i++)
    {
       fprintf(N,"\t\t%d\t\t%d\n",i,d_Cost[i]);
    }
    fprintf(N,"\n\t\t\tWHEN (DISTANCE) IS ACT LIKE A WEIGHT\n");
    fprintf(N,"\t\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
    fprintf(N,"\t\tNODE\tSHORTEST_DISTANCE\n");
    fprintf(N,"\t\t----\t-----------------\n");
    for(int i=1;i<=n;i++)
    {
       fprintf(N,"\t\t%d\t\t%d\n",i,d_Distance[i]);
    }
    }
    else if(k==5)
    {
        break;
    }
    else
        printf("\nWRONG KEY WORD\n");
    for(int g=1;g<100;g++)
    {
      flag_Time[g]=0;
      flag_Cost[g]=0;
      flag_Distance[g]=0;
    }

   }
    return 0;
}


